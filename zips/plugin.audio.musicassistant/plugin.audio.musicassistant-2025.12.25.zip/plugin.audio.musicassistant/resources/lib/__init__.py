# Music Assistant Kodi Addon - Library Package
# Version 2.0.0 - Compatible with Music Assistant Server 2.7+
