# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
import os
import json
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import re

addon = xbmcaddon.Addon()
addonID = addon.getAddonInfo('id')
if sys.version_info.major == 3:
    addonFolder = xbmcvfs.translatePath('special://home/addons/' + addonID)
else:
    addonFolder = xbmc.translatePath('special://home/addons/' + addonID).decode('utf-8')


def LOG(msg, level=xbmc.LOGINFO):
    """Log message to Kodi log"""
    if sys.version_info.major == 3:
        log_message = '{0}: {1}'.format(addonID, msg)
        xbmc.log(log_message, level)
    else:
        log_message = u'{0}: {1}'.format(addonID, msg)
        xbmc.log(log_message.encode("utf-8"), level)


def show_system_notification(title, message, icon=None, display_time=5000):
    """Show system notification instead of popup dialog"""
    if icon is None:
        icon = os.path.join(addonFolder, "icon.png")
    
    # Use Kodi's built-in notification system for system notifications
    xbmc.executebuiltin('Notification({0},{1},{2},{3})'.format(
        title, message, display_time, icon
    ))


def show_persistent_notification(title, message, icon=None):
    """Show notification that stays visible until replaced"""
    if icon is None:
        icon = os.path.join(addonFolder, "icon.png")
    
    # Use very long display time (30 seconds) to keep notification visible
    xbmc.executebuiltin('Notification({0},{1},{2},{3})'.format(
        title, message, 30000, icon
    ))


def getDownloadPath():
    """Get download path from settings"""
    path = addon.getSetting('download_path')
    if not path:
        path = xbmcgui.Dialog().browse(3, "Select Download Directory", 'files', '', False, True)
    if not path:
        return None
    addon.setSetting('download_path', path)
    return path


def get_plex_metadata(plex_id):
    """Get metadata from Plex to find the actual media file info"""
    LOG('Getting Plex metadata for ID: {0}'.format(plex_id), xbmc.LOGINFO)
    
    try:
        pkc_addon = xbmcaddon.Addon('plugin.video.plexkodiconnect')
        plex_token = pkc_addon.getSetting('accessToken')
        plex_server = pkc_addon.getSetting('ipaddress')
        plex_port = pkc_addon.getSetting('port')
        use_https = pkc_addon.getSetting('https') == 'true'
        
        if plex_server and plex_token:
            protocol = 'https' if use_https else 'http'
            
            # Get metadata to find the media part key
            import xml.etree.ElementTree as ET
            if sys.version_info.major == 3:
                import urllib.request
                import urllib.parse
                metadata_url = '{0}://{1}:{2}/library/metadata/{3}?X-Plex-Token={4}'.format(
                    protocol, plex_server, plex_port, plex_id, plex_token
                )
                req = urllib.request.Request(metadata_url)
                response = urllib.request.urlopen(req)
                xml_data = response.read()
            else:
                import urllib2
                metadata_url = '{0}://{1}:{2}/library/metadata/{3}?X-Plex-Token={4}'.format(
                    protocol, plex_server, plex_port, plex_id, plex_token
                )
                response = urllib2.urlopen(metadata_url)
                xml_data = response.read()
            
            root = ET.fromstring(xml_data)
            
            # Check if it's a music track
            track = root.find('.//Track')
            if track is not None:
                LOG('Found music track metadata', xbmc.LOGINFO)
                metadata = {
                    'type': 'track',
                    'title': track.get('title'),
                    'artist': track.get('grandparentTitle'),
                    'album': track.get('parentTitle'),
                    'track': track.get('index'),
                    'year': track.get('parentYear') or track.get('year'),
                    'duration': track.get('duration')
                }
                
                # Get download URL
                media = track.find('.//Media/Part')
                if media is not None:
                    part_key = media.get('key')
                    if part_key:
                        download_url = '{0}://{1}:{2}{3}?X-Plex-Token={4}'.format(
                            protocol, plex_server, plex_port, part_key, plex_token
                        )
                        metadata['download_url'] = download_url
                        return metadata
            
            # Otherwise check for video
            media = root.find('.//Media/Part')
            if media is not None:
                part_key = media.get('key')
                if part_key:
                    # Construct direct download URL
                    download_url = '{0}://{1}:{2}{3}?X-Plex-Token={4}'.format(
                        protocol, plex_server, plex_port, part_key, plex_token
                    )
                    LOG('Found direct download URL from metadata', xbmc.LOGINFO)
                    return {'download_url': download_url}
    except Exception as e:
        LOG('Could not get Plex metadata: {0}'.format(str(e)), xbmc.LOGERROR)
    
    return None


def get_plex_track_by_path(file_path):
    """Search Plex for a track by its file path and return download info"""
    LOG('Searching Plex for track by path: {0}'.format(file_path), xbmc.LOGINFO)
    
    try:
        pkc_addon = xbmcaddon.Addon('plugin.video.plexkodiconnect')
        plex_token = pkc_addon.getSetting('accessToken')
        plex_server = pkc_addon.getSetting('ipaddress')
        plex_port = pkc_addon.getSetting('port')
        use_https = pkc_addon.getSetting('https') == 'true'
        
        if not plex_server or not plex_token:
            LOG('Plex server or token not configured', xbmc.LOGERROR)
            return None
        
        protocol = 'https' if use_https else 'http'
        
        import xml.etree.ElementTree as ET
        if sys.version_info.major == 3:
            import urllib.request
            import urllib.parse
            
            # Extract filename from path for searching
            filename = os.path.basename(file_path)
            # Remove extension for better search
            search_term = os.path.splitext(filename)[0]
            
            # Search Plex for this track
            search_url = '{0}://{1}:{2}/search?query={3}&type=10&X-Plex-Token={4}'.format(
                protocol, plex_server, plex_port, urllib.parse.quote(search_term), plex_token
            )
            LOG('Plex search URL: {0}'.format(search_url.replace(plex_token, '***')), xbmc.LOGINFO)
            
            req = urllib.request.Request(search_url)
            response = urllib.request.urlopen(req)
            xml_data = response.read()
        else:
            import urllib2
            import urllib
            
            filename = os.path.basename(file_path)
            search_term = os.path.splitext(filename)[0]
            
            search_url = '{0}://{1}:{2}/search?query={3}&type=10&X-Plex-Token={4}'.format(
                protocol, plex_server, plex_port, urllib.quote(search_term), plex_token
            )
            
            response = urllib2.urlopen(search_url)
            xml_data = response.read()
        
        root = ET.fromstring(xml_data)
        
        # Find matching track
        for track in root.findall('.//Track'):
            # Check if file path matches
            part = track.find('.//Media/Part')
            if part is not None:
                plex_file = part.get('file', '')
                # Compare filenames (paths may differ due to mount points)
                if os.path.basename(plex_file) == os.path.basename(file_path):
                    LOG('Found matching track in Plex: {0}'.format(track.get('title')), xbmc.LOGINFO)
                    
                    part_key = part.get('key')
                    if part_key:
                        download_url = '{0}://{1}:{2}{3}?X-Plex-Token={4}'.format(
                            protocol, plex_server, plex_port, part_key, plex_token
                        )
                        return {
                            'plex_id': track.get('ratingKey'),
                            'download_url': download_url,
                            'title': track.get('title'),
                            'artist': track.get('grandparentTitle'),
                            'album': track.get('parentTitle'),
                            'track': track.get('index')
                        }
        
        LOG('No matching track found in Plex search results', xbmc.LOGINFO)
        
    except Exception as e:
        LOG('Error searching Plex for track: {0}'.format(str(e)), xbmc.LOGERROR)
    
    return None


def get_season_episodes(tvshow_id, season_num):
    """Get all episodes in a season"""
    LOG('Getting episodes for show ID {0}, season {1}'.format(tvshow_id, season_num), xbmc.LOGINFO)
    
    query = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetEpisodes",
        "params": {
            "tvshowid": tvshow_id,
            "season": season_num,
            "properties": ["file", "title", "episode", "season", "playcount"]
        },
        "id": 1
    }
    
    response = xbmc.executeJSONRPC(json.dumps(query))
    result = json.loads(response)
    
    if 'result' in result and 'episodes' in result['result']:
        return result['result']['episodes']
    
    return []


def get_all_episodes(tvshow_id):
    """Get all episodes in a TV show"""
    LOG('Getting all episodes for show ID {0}'.format(tvshow_id), xbmc.LOGINFO)
    
    query = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetEpisodes",
        "params": {
            "tvshowid": tvshow_id,
            "properties": ["file", "title", "episode", "season", "playcount"]
        },
        "id": 1
    }
    
    response = xbmc.executeJSONRPC(json.dumps(query))
    result = json.loads(response)
    
    if 'result' in result and 'episodes' in result['result']:
        return result['result']['episodes']
    
    return []


def get_unwatched_episodes_in_season(tvshow_id, season_num, limit=None):
    """Get unwatched episodes in a season, optionally limited to a certain number"""
    LOG('Getting unwatched episodes for show ID {0}, season {1}, limit {2}'.format(tvshow_id, season_num, limit), xbmc.LOGINFO)
    
    episodes = get_season_episodes(tvshow_id, season_num)
    
    # Filter to unwatched (playcount == 0)
    unwatched = [ep for ep in episodes if ep.get('playcount', 0) == 0]
    
    # Sort by episode number
    unwatched.sort(key=lambda x: x.get('episode', 0))
    
    if limit and limit > 0:
        unwatched = unwatched[:limit]
    
    LOG('Found {0} unwatched episodes in season'.format(len(unwatched)), xbmc.LOGINFO)
    return unwatched


def get_unwatched_episodes_in_show(tvshow_id, limit=None):
    """Get unwatched episodes in entire show, optionally limited to a certain number"""
    LOG('Getting unwatched episodes for show ID {0}, limit {1}'.format(tvshow_id, limit), xbmc.LOGINFO)
    
    episodes = get_all_episodes(tvshow_id)
    
    # Filter to unwatched (playcount == 0)
    unwatched = [ep for ep in episodes if ep.get('playcount', 0) == 0]
    
    # Sort by season then episode number
    unwatched.sort(key=lambda x: (x.get('season', 0), x.get('episode', 0)))
    
    if limit and limit > 0:
        unwatched = unwatched[:limit]
    
    LOG('Found {0} unwatched episodes in show'.format(len(unwatched)), xbmc.LOGINFO)
    return unwatched


def count_unwatched_in_season(tvshow_id, season_num):
    """Count unwatched episodes in a season"""
    episodes = get_season_episodes(tvshow_id, season_num)
    return len([ep for ep in episodes if ep.get('playcount', 0) == 0])


def count_unwatched_in_show(tvshow_id):
    """Count unwatched episodes in entire show"""
    episodes = get_all_episodes(tvshow_id)
    return len([ep for ep in episodes if ep.get('playcount', 0) == 0])


def get_tvshow_seasons(tvshow_id):
    """Get all seasons in a TV show"""
    LOG('Getting seasons for show ID {0}'.format(tvshow_id), xbmc.LOGINFO)
    
    query = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetSeasons",
        "params": {
            "tvshowid": tvshow_id,
            "properties": ["season", "episode"]
        },
        "id": 1
    }
    
    response = xbmc.executeJSONRPC(json.dumps(query))
    result = json.loads(response)
    
    if 'result' in result and 'seasons' in result['result']:
        return result['result']['seasons']
    
    return []


def get_tvshow_details(tvshow_id):
    """Get TV show details including title"""
    LOG('Getting show details for ID {0}'.format(tvshow_id), xbmc.LOGINFO)
    
    query = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShowDetails",
        "params": {
            "tvshowid": tvshow_id,
            "properties": ["title", "year"]
        },
        "id": 1
    }
    
    response = xbmc.executeJSONRPC(json.dumps(query))
    result = json.loads(response)
    
    if 'result' in result and 'tvshowdetails' in result['result']:
        return result['result']['tvshowdetails']
    
    return None


def get_album_songs(album_id):
    """Get all songs in an album"""
    LOG('Getting songs for album ID {0}'.format(album_id), xbmc.LOGINFO)
    
    query = {
        "jsonrpc": "2.0",
        "method": "AudioLibrary.GetSongs",
        "params": {
            "filter": {"albumid": album_id},
            "properties": ["file", "title", "track", "artist", "album"]
        },
        "id": 1
    }
    
    response = xbmc.executeJSONRPC(json.dumps(query))
    result = json.loads(response)
    
    if 'result' in result and 'songs' in result['result']:
        return result['result']['songs']
    
    return []


def get_artist_songs(artist_name):
    """Get all songs by an artist"""
    LOG('Getting songs for artist: {0}'.format(artist_name), xbmc.LOGINFO)
    
    query = {
        "jsonrpc": "2.0",
        "method": "AudioLibrary.GetSongs",
        "params": {
            "filter": {"artist": artist_name},
            "properties": ["file", "title", "track", "artist", "album", "albumid"]
        },
        "id": 1
    }
    
    response = xbmc.executeJSONRPC(json.dumps(query))
    result = json.loads(response)
    
    if 'result' in result and 'songs' in result['result']:
        return result['result']['songs']
    
    return []


def get_plex_full_metadata(plex_id):
    """Get full metadata from Plex including artwork URLs, plot, genres, etc."""
    LOG('Getting full Plex metadata for ID: {0}'.format(plex_id), xbmc.LOGINFO)
    
    try:
        pkc_addon = xbmcaddon.Addon('plugin.video.plexkodiconnect')
        plex_token = pkc_addon.getSetting('accessToken')
        plex_server = pkc_addon.getSetting('ipaddress')
        plex_port = pkc_addon.getSetting('port')
        use_https = pkc_addon.getSetting('https') == 'true'
        
        if not plex_server or not plex_token:
            return None
        
        protocol = 'https' if use_https else 'http'
        base_url = '{0}://{1}:{2}'.format(protocol, plex_server, plex_port)
        
        import xml.etree.ElementTree as ET
        if sys.version_info.major == 3:
            import urllib.request
            metadata_url = '{0}/library/metadata/{1}?X-Plex-Token={2}'.format(base_url, plex_id, plex_token)
            req = urllib.request.Request(metadata_url)
            response = urllib.request.urlopen(req)
            xml_data = response.read()
        else:
            import urllib2
            metadata_url = '{0}/library/metadata/{1}?X-Plex-Token={2}'.format(base_url, plex_id, plex_token)
            response = urllib2.urlopen(metadata_url)
            xml_data = response.read()
        
        root = ET.fromstring(xml_data)
        
        # Try to find Video (movie/episode) or Track (music)
        video = root.find('.//Video')
        track = root.find('.//Track')
        
        metadata = {}
        
        if video is not None:
            metadata['title'] = video.get('title', '')
            metadata['year'] = video.get('year', '')
            metadata['plot'] = video.get('summary', '')
            metadata['tagline'] = video.get('tagline', '')
            metadata['rating'] = video.get('rating', '')
            metadata['runtime'] = video.get('duration', '')
            metadata['studio'] = video.get('studio', '')
            metadata['mpaa'] = video.get('contentRating', '')
            metadata['originally_available'] = video.get('originallyAvailableAt', '')
            
            # Get poster/thumb
            thumb = video.get('thumb', '')
            if thumb:
                metadata['poster_url'] = '{0}{1}?X-Plex-Token={2}'.format(base_url, thumb, plex_token)
            
            # Get art/fanart
            art = video.get('art', '')
            if art:
                metadata['fanart_url'] = '{0}{1}?X-Plex-Token={2}'.format(base_url, art, plex_token)
            
            # Get genres
            genres = []
            for genre in video.findall('.//Genre'):
                genres.append(genre.get('tag', ''))
            metadata['genres'] = genres
            
            # Get directors
            directors = []
            for director in video.findall('.//Director'):
                directors.append(director.get('tag', ''))
            metadata['directors'] = directors
            
            # Get writers
            writers = []
            for writer in video.findall('.//Writer'):
                writers.append(writer.get('tag', ''))
            metadata['writers'] = writers
            
            # Get actors
            actors = []
            for role in video.findall('.//Role'):
                actors.append({
                    'name': role.get('tag', ''),
                    'role': role.get('role', ''),
                    'thumb': role.get('thumb', '')
                })
            metadata['actors'] = actors
            
            # Episode specific
            metadata['season'] = video.get('parentIndex', '')
            metadata['episode'] = video.get('index', '')
            metadata['show_title'] = video.get('grandparentTitle', '')
            
        elif track is not None:
            metadata['title'] = track.get('title', '')
            metadata['artist'] = track.get('grandparentTitle', '')
            metadata['album'] = track.get('parentTitle', '')
            metadata['track'] = track.get('index', '')
            metadata['year'] = track.get('parentYear', '') or track.get('year', '')
            
            thumb = track.get('thumb', '') or track.get('parentThumb', '')
            if thumb:
                metadata['poster_url'] = '{0}{1}?X-Plex-Token={2}'.format(base_url, thumb, plex_token)
        
        return metadata
        
    except Exception as e:
        LOG('Error getting full Plex metadata: {0}'.format(str(e)), xbmc.LOGERROR)
        return None


def download_artwork(url, dest_path):
    """Download artwork from URL to destination path"""
    LOG('Downloading artwork to: {0}'.format(dest_path), xbmc.LOGINFO)
    
    try:
        if sys.version_info.major == 3:
            import urllib.request
            urllib.request.urlretrieve(url, dest_path)
        else:
            import urllib
            urllib.urlretrieve(url, dest_path)
        return True
    except Exception as e:
        LOG('Error downloading artwork: {0}'.format(str(e)), xbmc.LOGERROR)
        return False


def write_nfo_file(dest_file, item_info, metadata=None, plex_metadata=None):
    """Write .nfo metadata file for Kodi with full metadata"""
    nfo_file = os.path.splitext(dest_file)[0] + '.nfo'
    
    # Helper to escape XML
    def escape_xml(text):
        if text is None:
            return ''
        text = str(text)
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        return text
    
    try:
        if item_info['type'] == 'song' or item_info['type'] == 'music':
            # Music NFO format
            nfo_content = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            nfo_content += '<musicvideo>\n'
            nfo_content += '    <title>{0}</title>\n'.format(escape_xml(item_info.get('title', 'Unknown')))
            
            if plex_metadata:
                if plex_metadata.get('artist'):
                    nfo_content += '    <artist>{0}</artist>\n'.format(escape_xml(plex_metadata['artist']))
                if plex_metadata.get('album'):
                    nfo_content += '    <album>{0}</album>\n'.format(escape_xml(plex_metadata['album']))
                if plex_metadata.get('track'):
                    nfo_content += '    <track>{0}</track>\n'.format(escape_xml(plex_metadata['track']))
                if plex_metadata.get('year'):
                    nfo_content += '    <year>{0}</year>\n'.format(escape_xml(plex_metadata['year']))
            elif metadata:
                if metadata.get('artist'):
                    nfo_content += '    <artist>{0}</artist>\n'.format(escape_xml(metadata['artist']))
                if metadata.get('album'):
                    nfo_content += '    <album>{0}</album>\n'.format(escape_xml(metadata['album']))
                if metadata.get('track'):
                    nfo_content += '    <track>{0}</track>\n'.format(escape_xml(metadata['track']))
                if metadata.get('year'):
                    nfo_content += '    <year>{0}</year>\n'.format(escape_xml(metadata['year']))
            else:
                artist = item_info.get('artist', 'Unknown')
                if isinstance(artist, list):
                    artist = artist[0] if artist else 'Unknown'
                nfo_content += '    <artist>{0}</artist>\n'.format(escape_xml(artist))
                nfo_content += '    <album>{0}</album>\n'.format(escape_xml(item_info.get('album', 'Unknown')))
                if item_info.get('track'):
                    nfo_content += '    <track>{0}</track>\n'.format(escape_xml(item_info['track']))
            
            nfo_content += '</musicvideo>\n'
        
        elif item_info['type'] == 'episode':
            # TV Episode NFO format
            nfo_content = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            nfo_content += '<episodedetails>\n'
            nfo_content += '    <title>{0}</title>\n'.format(escape_xml(item_info.get('title', 'Unknown')))
            
            if plex_metadata:
                if plex_metadata.get('season'):
                    nfo_content += '    <season>{0}</season>\n'.format(escape_xml(plex_metadata['season']))
                if plex_metadata.get('episode'):
                    nfo_content += '    <episode>{0}</episode>\n'.format(escape_xml(plex_metadata['episode']))
                if plex_metadata.get('plot'):
                    nfo_content += '    <plot>{0}</plot>\n'.format(escape_xml(plex_metadata['plot']))
                if plex_metadata.get('rating'):
                    nfo_content += '    <rating>{0}</rating>\n'.format(escape_xml(plex_metadata['rating']))
                if plex_metadata.get('originally_available'):
                    nfo_content += '    <aired>{0}</aired>\n'.format(escape_xml(plex_metadata['originally_available']))
                if plex_metadata.get('directors'):
                    for director in plex_metadata['directors']:
                        nfo_content += '    <director>{0}</director>\n'.format(escape_xml(director))
                if plex_metadata.get('writers'):
                    for writer in plex_metadata['writers']:
                        nfo_content += '    <credits>{0}</credits>\n'.format(escape_xml(writer))
            else:
                if item_info.get('season'):
                    nfo_content += '    <season>{0}</season>\n'.format(escape_xml(item_info['season']))
                if item_info.get('episode'):
                    nfo_content += '    <episode>{0}</episode>\n'.format(escape_xml(item_info['episode']))
            
            nfo_content += '</episodedetails>\n'
        
        else:
            # Movie NFO format
            nfo_content = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            nfo_content += '<movie>\n'
            nfo_content += '    <title>{0}</title>\n'.format(escape_xml(item_info.get('title', 'Unknown')))
            
            if plex_metadata:
                if plex_metadata.get('year'):
                    nfo_content += '    <year>{0}</year>\n'.format(escape_xml(plex_metadata['year']))
                if plex_metadata.get('plot'):
                    nfo_content += '    <plot>{0}</plot>\n'.format(escape_xml(plex_metadata['plot']))
                if plex_metadata.get('tagline'):
                    nfo_content += '    <tagline>{0}</tagline>\n'.format(escape_xml(plex_metadata['tagline']))
                if plex_metadata.get('rating'):
                    nfo_content += '    <rating>{0}</rating>\n'.format(escape_xml(plex_metadata['rating']))
                if plex_metadata.get('mpaa'):
                    nfo_content += '    <mpaa>{0}</mpaa>\n'.format(escape_xml(plex_metadata['mpaa']))
                if plex_metadata.get('runtime'):
                    # Convert from ms to minutes
                    try:
                        runtime_min = int(int(plex_metadata['runtime']) / 60000)
                        nfo_content += '    <runtime>{0}</runtime>\n'.format(runtime_min)
                    except:
                        pass
                if plex_metadata.get('studio'):
                    nfo_content += '    <studio>{0}</studio>\n'.format(escape_xml(plex_metadata['studio']))
                if plex_metadata.get('originally_available'):
                    nfo_content += '    <premiered>{0}</premiered>\n'.format(escape_xml(plex_metadata['originally_available']))
                if plex_metadata.get('genres'):
                    for genre in plex_metadata['genres']:
                        nfo_content += '    <genre>{0}</genre>\n'.format(escape_xml(genre))
                if plex_metadata.get('directors'):
                    for director in plex_metadata['directors']:
                        nfo_content += '    <director>{0}</director>\n'.format(escape_xml(director))
                if plex_metadata.get('writers'):
                    for writer in plex_metadata['writers']:
                        nfo_content += '    <credits>{0}</credits>\n'.format(escape_xml(writer))
                if plex_metadata.get('actors'):
                    for actor in plex_metadata['actors']:
                        nfo_content += '    <actor>\n'
                        nfo_content += '        <name>{0}</name>\n'.format(escape_xml(actor.get('name', '')))
                        if actor.get('role'):
                            nfo_content += '        <role>{0}</role>\n'.format(escape_xml(actor['role']))
                        nfo_content += '    </actor>\n'
            else:
                if item_info.get('year'):
                    nfo_content += '    <year>{0}</year>\n'.format(escape_xml(item_info['year']))
            
            nfo_content += '</movie>\n'
        
        # Write NFO file
        nfo_file_obj = xbmcvfs.File(nfo_file, 'w')
        nfo_file_obj.write(nfo_content.encode('utf-8') if sys.version_info.major == 3 else nfo_content)
        nfo_file_obj.close()
        
        LOG('Wrote NFO file: {0}'.format(nfo_file), xbmc.LOGINFO)
        
        # Download artwork if enabled
        download_artwork_setting = addon.getSetting('download_artwork') == 'true'
        if download_artwork_setting and plex_metadata:
            base_name = os.path.splitext(dest_file)[0]
            
            # Download poster
            if plex_metadata.get('poster_url'):
                poster_ext = '.jpg'
                if item_info['type'] == 'episode':
                    poster_file = base_name + '-thumb' + poster_ext
                else:
                    poster_file = base_name + '-poster' + poster_ext
                download_artwork(plex_metadata['poster_url'], poster_file)
            
            # Download fanart for movies
            if plex_metadata.get('fanart_url') and item_info['type'] == 'movie':
                fanart_file = base_name + '-fanart.jpg'
                download_artwork(plex_metadata['fanart_url'], fanart_file)
        
        return True
    
    except Exception as e:
        LOG('Could not write NFO file: {0}'.format(str(e)), xbmc.LOGERROR)
        return False


def delete_downloads_by_type(media_type):
    """Delete all downloads of a specific media type"""
    download_path = addon.getSetting('download_path')
    if not download_path:
        return False
    
    organize_by_type = addon.getSetting('organize_by_type') == 'true'
    
    if organize_by_type:
        if media_type == 'movies':
            target_path = os.path.join(download_path, 'Movies')
        elif media_type == 'tvshows':
            target_path = os.path.join(download_path, 'TV Shows')
        elif media_type == 'music':
            target_path = os.path.join(download_path, 'Music')
        else:
            return False
    else:
        # If not organized by type, we can't easily separate them
        show_system_notification(
            'Cannot Delete',
            'Enable "Organize by Media Type" in settings first'
        )
        return False
    
    if not xbmcvfs.exists(target_path):
        show_system_notification(
            'Nothing to Delete',
            'No {0} folder found.'.format(media_type)
        )
        return False
    
    # Count files first
    import shutil
    
    confirm = xbmcgui.Dialog().yesno(
        'Confirm Delete',
        'Are you sure you want to delete ALL downloaded {0}?[CR][CR]This will delete everything in:[CR]{1}'.format(media_type, target_path),
        nolabel='Cancel',
        yeslabel='Delete All'
    )
    
    if not confirm:
        return False
    
    # Double confirm for safety
    confirm2 = xbmcgui.Dialog().yesno(
        'FINAL WARNING',
        'This action CANNOT be undone![CR][CR]Delete all {0}?'.format(media_type),
        nolabel='Cancel',
        yeslabel='Yes, Delete Everything'
    )
    
    if not confirm2:
        return False
    
    try:
        # Use shutil to remove directory tree
        if sys.version_info.major == 3:
            shutil.rmtree(xbmcvfs.translatePath(target_path))
        else:
            shutil.rmtree(xbmc.translatePath(target_path).decode('utf-8'))
        
        show_system_notification(
            'Deleted',
            'All {0} have been deleted'.format(media_type)
        )
        return True
    except Exception as e:
        LOG('Error deleting {0}: {1}'.format(media_type, str(e)), xbmc.LOGERROR)
        show_system_notification(
            'Error',
            'Could not delete files: {0}'.format(str(e))
        )
        return False


def get_plex_item_info():
    """Get information about the currently selected Plex item"""
    if not hasattr(sys, 'listitem'):
        LOG('Could not access listitem', xbmc.LOGERROR)
        return None
    
    listitem = sys.listitem
    file_path = listitem.getPath()
    title = listitem.getLabel()
    
    LOG('ListItem Path: |{0}|'.format(file_path), xbmc.LOGINFO)
    LOG('ListItem Title: |{0}|'.format(title), xbmc.LOGINFO)
    
    plex_id = None
    content_type = 'movie'
    episode_id = None
    tvshow_id = None
    season_num = None
    song_id = None
    album_id = None
    artist_id = None
    
    # If it's a videodb path, get the actual file path using JSON-RPC
    if file_path.startswith('videodb://'):
        LOG('Video database path detected, getting actual file path', xbmc.LOGINFO)
        
        # Strip query string for pattern matching
        base_path = file_path.split('?')[0]
        
        # Check if it's a TV show directory (e.g., videodb://tvshows/titles/123/)
        tvshow_dir_match = re.search(r'videodb://tvshows/titles/(\d+)/$', base_path)
        if tvshow_dir_match:
            tvshow_id = int(tvshow_dir_match.group(1))
            content_type = 'tvshow'
            LOG('Detected TV show directory, show ID: {0}'.format(tvshow_id), xbmc.LOGINFO)
            
            # Get show details
            show_details = get_tvshow_details(tvshow_id)
            if show_details:
                title = show_details.get('title', title)
            
            return {
                'path': file_path,
                'title': title,
                'plex_id': None,
                'year': listitem.getProperty('year'),
                'type': content_type,
                'episode_id': None,
                'tvshow_id': tvshow_id,
                'season': None,
                'song_id': None,
                'album_id': None,
                'artist_id': None,
                'artist': None,
                'album': None,
                'track': 0
            }
        
        # Check if it's a season directory (e.g., videodb://tvshows/titles/123/1/ or videodb://tvshows/titles/123/-1/)
        season_dir_match = re.search(r'videodb://tvshows/titles/(\d+)/(-?\d+)/$', base_path)
        if season_dir_match:
            tvshow_id = int(season_dir_match.group(1))
            season_num = int(season_dir_match.group(2))
            content_type = 'season'
            LOG('Detected season directory, show ID: {0}, season: {1}'.format(tvshow_id, season_num), xbmc.LOGINFO)
            
            # Get show details for the title
            show_details = get_tvshow_details(tvshow_id)
            show_title = show_details.get('title', 'Unknown') if show_details else 'Unknown'
            
            return {
                'path': file_path,
                'title': title,
                'show_title': show_title,
                'plex_id': None,
                'year': listitem.getProperty('year'),
                'type': content_type,
                'episode_id': None,
                'tvshow_id': tvshow_id,
                'season': season_num,
                'song_id': None,
                'album_id': None,
                'artist_id': None,
                'artist': None,
                'album': None,
                'track': 0
            }
        
        # Check if it's a movie
        movie_match = re.search(r'videodb://movies/titles/(\d+)', file_path)
        if movie_match:
            movie_id = int(movie_match.group(1))
            LOG('Extracted movie ID: {0}'.format(movie_id), xbmc.LOGINFO)
            
            query = {
                "jsonrpc": "2.0",
                "method": "VideoLibrary.GetMovieDetails",
                "params": {
                    "movieid": movie_id,
                    "properties": ["file"]
                },
                "id": 1
            }
            
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            LOG('JSON-RPC response: {0}'.format(result), xbmc.LOGINFO)
            
            if 'result' in result and 'moviedetails' in result['result']:
                file_path = result['result']['moviedetails'].get('file', '')
                LOG('Got actual file path from database: |{0}|'.format(file_path), xbmc.LOGINFO)
        
        # Check if it's a TV episode
        episode_match = re.search(r'videodb://tvshows/titles/(-?\d+)/(-?\d+)/(\d+)', file_path)
        if episode_match:
            episode_id = int(episode_match.group(3))
            content_type = 'episode'
            LOG('Extracted episode ID: {0}'.format(episode_id), xbmc.LOGINFO)
            
            query = {
                "jsonrpc": "2.0",
                "method": "VideoLibrary.GetEpisodeDetails",
                "params": {
                    "episodeid": episode_id,
                    "properties": ["file", "tvshowid", "season"]
                },
                "id": 1
            }
            
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            LOG('JSON-RPC response: {0}'.format(result), xbmc.LOGINFO)
            
            if 'result' in result and 'episodedetails' in result['result']:
                file_path = result['result']['episodedetails'].get('file', '')
                tvshow_id = result['result']['episodedetails'].get('tvshowid')
                season_num = result['result']['episodedetails'].get('season')
                LOG('Got episode file path: |{0}|'.format(file_path), xbmc.LOGINFO)
    
    # Check if it's a music item
    if file_path.startswith('musicdb://'):
        LOG('Music database path detected, getting actual file path', xbmc.LOGINFO)
        
        # Strip query string for pattern matching
        base_music_path = file_path.split('?')[0]
        
        # Check if it's an artist directory (e.g., musicdb://artists/123/)
        artist_dir_match = re.search(r'musicdb://artists/(\d+)/?$', base_music_path)
        if artist_dir_match:
            artist_id = int(artist_dir_match.group(1))
            content_type = 'artist'
            LOG('Detected artist directory, artist ID: {0}'.format(artist_id), xbmc.LOGINFO)
            
            # Get artist details
            query = {
                "jsonrpc": "2.0",
                "method": "AudioLibrary.GetArtistDetails",
                "params": {
                    "artistid": artist_id,
                    "properties": ["artist"]
                },
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            
            artist_name = title
            if 'result' in result and 'artistdetails' in result['result']:
                details = result['result']['artistdetails']
                artist_name = details.get('artist', title)
            
            return {
                'path': file_path,
                'title': artist_name,
                'plex_id': None,
                'year': listitem.getProperty('year'),
                'type': content_type,
                'episode_id': None,
                'tvshow_id': None,
                'season': None,
                'song_id': None,
                'album_id': None,
                'artist_id': artist_id,
                'artist': artist_name,
                'album': None,
                'track': 0
            }
        
        # Check if it's an album directory (e.g., musicdb://albums/123/ or musicdb://artists/1/123/)
        album_dir_match = re.search(r'musicdb://(?:albums|artists/\d+)/(\d+)/?$', base_music_path)
        if album_dir_match:
            album_id = int(album_dir_match.group(1))
            content_type = 'album'
            LOG('Detected album directory, album ID: {0}'.format(album_id), xbmc.LOGINFO)
            
            # Get album details
            query = {
                "jsonrpc": "2.0",
                "method": "AudioLibrary.GetAlbumDetails",
                "params": {
                    "albumid": album_id,
                    "properties": ["title", "artist", "artistid"]
                },
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            
            album_title = title
            artist_name = None
            if 'result' in result and 'albumdetails' in result['result']:
                details = result['result']['albumdetails']
                album_title = details.get('title', title)
                artists = details.get('artist', [])
                if artists:
                    artist_name = artists[0]
            
            return {
                'path': file_path,
                'title': album_title,
                'plex_id': None,
                'year': listitem.getProperty('year'),
                'type': content_type,
                'episode_id': None,
                'tvshow_id': None,
                'season': None,
                'song_id': None,
                'album_id': album_id,
                'artist_id': None,
                'artist': artist_name,
                'album': album_title,
                'track': 0
            }
        
        content_type = 'song'
        
        # Check if it's a song
        song_match = re.search(r'musicdb://songs/(\d+)', file_path)
        if song_match:
            song_id = int(song_match.group(1))
            LOG('Extracted song ID: {0}'.format(song_id), xbmc.LOGINFO)
            
            query = {
                "jsonrpc": "2.0",
                "method": "AudioLibrary.GetSongDetails",
                "params": {
                    "songid": song_id,
                    "properties": ["file", "albumid", "artist", "album", "track", "title"]
                },
                "id": 1
            }
            
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            LOG('JSON-RPC response: {0}'.format(result), xbmc.LOGINFO)
            
            if 'result' in result and 'songdetails' in result['result']:
                details = result['result']['songdetails']
                file_path = details.get('file', '')
                album_id = details.get('albumid')
                title = details.get('title', title)
                LOG('Got song file path: |{0}|'.format(file_path), xbmc.LOGINFO)
    
    # Extract Plex ID from the path
    match = re.search(r'plex_id=(\d+)', file_path)
    if match:
        plex_id = match.group(1)
        LOG('Extracted Plex ID: {0}'.format(plex_id), xbmc.LOGINFO)
    
    LOG('Final file path: |{0}|'.format(file_path), xbmc.LOGINFO)
    LOG('Content type: |{0}|'.format(content_type), xbmc.LOGINFO)
    
    # Check if this is a Plex item or network path
    is_network = (file_path.startswith('smb://') or 
                  file_path.startswith('nfs://') or 
                  file_path.startswith('http://') or 
                  file_path.startswith('https://'))
    
    is_plex = ('plex' in file_path.lower() or 
               file_path.startswith('plugin://plugin.video.plexkodiconnect') or 
               file_path.startswith('plugin://plugin.audio.plexkodiconnect'))
    
    # Also allow musicdb paths that contain plex content (determined by checking actual files)
    is_musicdb = file_path.startswith('musicdb://')
    
    if not is_network and not is_plex and not is_musicdb:
        LOG('Not a Plex/network/musicdb item: {0}'.format(file_path), xbmc.LOGERROR)
        return None
    
    return {
        'path': file_path,
        'title': title,
        'plex_id': plex_id,
        'year': listitem.getProperty('year'),
        'type': content_type,
        'episode_id': episode_id,
        'tvshow_id': tvshow_id,
        'season': season_num,
        'song_id': song_id,
        'album_id': album_id,
        'artist_id': artist_id,
        'artist': listitem.getProperty('artist') if content_type == 'song' else None,
        'album': listitem.getProperty('album') if content_type == 'song' else None,
        'track': int(listitem.getProperty('tracknumber')) if listitem.getProperty('tracknumber') else 0
    }


def copy_with_progress(source, dest, title, pDialog):
    """Copy file with progress updates"""
    LOG("Copying from {0} to {1}".format(source, dest), xbmc.LOGINFO)
    
    # Track last percentage to avoid duplicate notifications
    last_percent = -1
    
    try:
        # Get file size for progress calculation
        if source.startswith('http://') or source.startswith('https://'):
            # For HTTP streams, we'll use chunked reading
            if sys.version_info.major == 3:
                import urllib.request
                req = urllib.request.Request(source)
                response = urllib.request.urlopen(req)
            else:
                import urllib2
                response = urllib2.urlopen(source)
            
            file_size = int(response.headers.get('Content-Length', 0))
            
            # Download in chunks
            chunk_size = 8192
            bytes_downloaded = 0
            
            with open(dest if dest.startswith('/') else xbmcvfs.translatePath(dest), 'wb') as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    bytes_downloaded += len(chunk)
                    
                    if file_size > 0:
                        percent = int((bytes_downloaded / file_size) * 100)
                        if pDialog:  # Only update if dialog exists
                            pDialog.update(percent, 'Downloading {0}... {1}%'.format(title, percent))
                        elif percent != last_percent and percent % 5 == 0:  # Update notification every 5% and only when changed
                            show_persistent_notification('Downloading', '{0} - {1}%'.format(title, percent))
                            last_percent = percent
            
            return True
        else:
            # For local/network files, use xbmcvfs
            if pDialog:
                pDialog.update(10, 'Copying {0}...'.format(title))
            else:
                show_persistent_notification('Downloading', '{0} - 10%'.format(title))
                last_percent = 10
            
            if xbmcvfs.copy(source, dest):
                if pDialog:
                    pDialog.update(100, 'Download complete')
                else:
                    show_persistent_notification('Download Complete', '{0} - 100%'.format(title))
                return True
            else:
                # Alternative method - read entire file
                LOG("xbmcvfs.copy failed, trying alternative method", xbmc.LOGINFO)
                if pDialog:
                    pDialog.update(20, 'Reading file...')
                else:
                    show_persistent_notification('Downloading', '{0} - 20%'.format(title))
                    last_percent = 20
                
                src_file = xbmcvfs.File(source, 'rb')
                file_data = src_file.readBytes()
                src_file.close()
                
                if pDialog:
                    pDialog.update(60, 'Writing file...')
                else:
                    show_persistent_notification('Downloading', '{0} - 60%'.format(title))
                    last_percent = 60
                
                dst_file = xbmcvfs.File(dest, 'wb')
                dst_file.write(file_data)
                dst_file.close()
                
                # Verify
                if xbmcvfs.exists(dest):
                    src_stat = xbmcvfs.Stat(source)
                    dst_stat = xbmcvfs.Stat(dest)
                    
                    if sys.version_info.major == 3:
                        src_size = src_stat.st_size()
                        dst_size = dst_stat.st_size()
                    else:
                        src_size = src_stat.st_size()
                        dst_size = dst_stat.st_size()
                    
                    if src_size == dst_size:
                        if pDialog:
                            pDialog.update(100, 'Download complete')
                        else:
                            show_persistent_notification('Download Complete', '{0} - 100%'.format(title))
                        return True
                
                return False
    except Exception as e:
        LOG('Copy error: {0}'.format(str(e)), xbmc.LOGERROR)
        return False


def download_episodes(episodes, tvshow_id, title='Download', show_confirm=True):
    """Download a list of episodes"""
    if not episodes:
        show_system_notification(
            'PlexKodiConnect Download',
            'No episodes to download'
        )
        return False
    
    if show_confirm:
        confirm = xbmcgui.Dialog().yesno(
            title,
            'Download {0} episodes?'.format(len(episodes))
        )
        
        if not confirm:
            return False
    
    success_count = 0
    fail_count = 0
    
    # Show progress via system notifications instead of dialog
    show_system_notification(title, 'Starting download of {0} episodes...'.format(len(episodes)))
    
    for idx, episode in enumerate(episodes):
        # Show progress notification every 5 episodes or for first/last
        if idx == 0 or idx == len(episodes) - 1 or (idx + 1) % 5 == 0:
            overall_percent = int((idx / len(episodes)) * 100)
            show_system_notification(
                'Download Progress', 
                'Episode {0} of {1}: S{2:02d}E{3:02d} - {4} ({5}%)'.format(
                    idx + 1, len(episodes), episode.get('season', 0), episode.get('episode', 0), 
                    episode.get('title', 'Unknown'), overall_percent
                )
            )
        
        file_path = episode.get('file', '')
        
        # Check for plex_id or Plex direct URL
        plex_id_match = re.search(r'plex_id=(\d+)', file_path)
        plex_direct_match = re.search(r'plex\.direct.*?/library/parts/(\d+)/', file_path)
        
        plex_id = None
        download_url = None
        
        if plex_id_match:
            plex_id = plex_id_match.group(1)
        elif plex_direct_match:
            plex_id = plex_direct_match.group(1)
            download_url = file_path
        else:
            # Try extracting from standard path
            match = re.search(r'plex_id=(\d+)', file_path)
            if match:
                plex_id = match.group(1)
        
        if plex_id or download_url:
            ep_info = {
                'path': download_url if download_url else file_path,
                'title': episode.get('title', 'Unknown'),
                'plex_id': plex_id,
                'type': 'episode',
                'season': episode.get('season', 0),
                'episode': episode.get('episode', 0),
                'tvshow_id': tvshow_id
            }
            
            if download_single_item(ep_info, show_notifications=False):
                success_count += 1
            else:
                fail_count += 1
        else:
            LOG('No plex_id found for episode: {0}'.format(episode.get('title', 'Unknown')), xbmc.LOGWARNING)
            fail_count += 1
    
    # Progress notifications handled in loop
    
    show_system_notification(
        'Download Complete',
        'Downloaded: {0}, Failed: {1}'.format(success_count, fail_count)
    )
    
    return True


def download_season(tvshow_id, season_num):
    """Download an entire season"""
    episodes = get_season_episodes(tvshow_id, season_num)
    
    if not episodes:
        show_system_notification(
            'PlexKodiConnect Download',
            'No episodes found in season'
        )
        return False
    
    # Get show title for the confirmation message
    show_details = get_tvshow_details(tvshow_id)
    show_title = show_details.get('title', 'Unknown Show') if show_details else 'Unknown Show'
    
    if season_num == 0:
        season_label = 'Specials'
    else:
        season_label = 'Season {0}'.format(season_num)
    
    confirm = xbmcgui.Dialog().yesno(
        'Download {0}'.format(season_label),
        'Download {0} episodes of "{1}" - {2}?'.format(len(episodes), show_title, season_label)
    )
    
    if not confirm:
        return False
    
    success_count = 0
    fail_count = 0
    
    # Show progress via system notifications instead of dialog
    show_system_notification('Downloading {0}'.format(season_label), 'Starting download of {0} episodes...'.format(len(episodes)))
    
    for idx, episode in enumerate(episodes):
        # Show progress notification every 5 episodes or for first/last
        if idx == 0 or idx == len(episodes) - 1 or (idx + 1) % 5 == 0:
            overall_percent = int((idx / len(episodes)) * 100)
            show_system_notification(
                'Season Download Progress', 
                'Episode {0} of {1}: {2} ({3}%)'.format(
                    idx + 1, len(episodes), episode['title'], overall_percent
                )
            )
        
        # Extract plex_id from episode file path
        match = re.search(r'plex_id=(\d+)', episode['file'])
        if match:
            ep_info = {
                'path': episode['file'],
                'title': episode['title'],
                'plex_id': match.group(1),
                'type': 'episode',
                'season': episode['season'],
                'episode': episode['episode'],
                'tvshow_id': tvshow_id
            }
            
            if download_single_item(ep_info, show_notifications=False):
                success_count += 1
            else:
                fail_count += 1
    
    # Progress notifications handled in loop
    
    show_system_notification(
        'Season Download Complete',
        'Downloaded: {0}, Failed: {1}'.format(success_count, fail_count)
    )
    
    return True


def download_show(tvshow_id):
    """Download an entire TV show"""
    episodes = get_all_episodes(tvshow_id)
    
    if not episodes:
        show_system_notification(
            'PlexKodiConnect Download',
            'No episodes found'
        )
        return False
    
    # Get show title for the confirmation message
    show_details = get_tvshow_details(tvshow_id)
    show_title = show_details.get('title', 'Unknown Show') if show_details else 'Unknown Show'
    
    # Count seasons
    seasons = set(ep['season'] for ep in episodes)
    
    confirm = xbmcgui.Dialog().yesno(
        'Download Entire Show',
        'Download all {0} episodes ({1} seasons) of "{2}"?'.format(len(episodes), len(seasons), show_title)
    )
    
    if not confirm:
        return False
    
    success_count = 0
    fail_count = 0
    
    # Show progress via system notifications instead of dialog
    show_system_notification('Downloading "{0}"'.format(show_title), 'Starting download of {0} episodes...'.format(len(episodes)))
    
    for idx, episode in enumerate(episodes):
        # Show progress notification every 10 episodes or for first/last
        if idx == 0 or idx == len(episodes) - 1 or (idx + 1) % 10 == 0:
            overall_percent = int((idx / len(episodes)) * 100)
            show_system_notification(
                'Show Download Progress', 
                'Episode {0} of {1}: S{2:02d}E{3:02d} - {4} ({5}%)'.format(
                    idx + 1, len(episodes), episode['season'], episode['episode'], 
                    episode['title'], overall_percent
                )
            )
        
        # Extract plex_id from episode file path
        match = re.search(r'plex_id=(\d+)', episode['file'])
        if match:
            ep_info = {
                'path': episode['file'],
                'title': episode['title'],
                'plex_id': match.group(1),
                'type': 'episode',
                'season': episode['season'],
                'episode': episode['episode'],
                'tvshow_id': tvshow_id
            }
            
            if download_single_item(ep_info, show_notifications=False):
                success_count += 1
            else:
                fail_count += 1
    
    # Progress notifications handled in loop
    
    show_system_notification(
        'Show Download Complete',
        'Downloaded: {0}, Failed: {1}'.format(success_count, fail_count)
    )
    
    return True


def download_album(album_id, album_name=None):
    """Download an entire album"""
    songs = get_album_songs(album_id)
    
    LOG('download_album: Found {0} songs for album ID {1}'.format(len(songs) if songs else 0, album_id), xbmc.LOGINFO)
    
    if not songs:
        show_system_notification(
            'PlexKodiConnect Download',
            'No songs found in album'
        )
        return False
    
    if not album_name and songs:
        album_name = songs[0].get('album', 'Unknown Album')
    
    confirm = xbmcgui.Dialog().yesno(
        'Download Album',
        'Download {0} songs from "{1}"?'.format(len(songs), album_name)
    )
    
    if not confirm:
        return False
    
    success_count = 0
    fail_count = 0
    skipped_count = 0
    
    # Show progress via system notifications instead of dialog
    show_system_notification('Downloading Album', 'Starting download of {0} songs...'.format(len(songs)))
    
    for idx, song in enumerate(songs):
        # Show progress notification every 5 songs or for first/last
        if idx == 0 or idx == len(songs) - 1 or (idx + 1) % 5 == 0:
            overall_percent = int((idx / len(songs)) * 100)
            show_system_notification(
                'Album Download Progress', 
                'Song {0} of {1}: {2} ({3}%)'.format(
                    idx + 1, len(songs), song.get('title', 'Unknown'), overall_percent
                )
            )
        
        file_path = song.get('file', '')
        LOG('download_album: Processing song "{0}" with path: {1}'.format(song.get('title', 'Unknown'), file_path), xbmc.LOGINFO)
        
        # Check if this is already a Plex direct download URL
        # Format: https://xxx.plex.direct:32400/library/parts/12345/...
        plex_direct_match = re.search(r'plex\.direct.*?/library/parts/(\d+)/', file_path)
        
        plex_id = None
        download_url = None
        
        # Extract plex_id from song file path (plugin style)
        plex_id_match = re.search(r'plex_id=(\d+)', file_path)
        
        if plex_id_match:
            plex_id = plex_id_match.group(1)
        elif plex_direct_match:
            # This is already a direct Plex download URL - use it directly
            plex_id = plex_direct_match.group(1)  # Use part ID as identifier
            download_url = file_path  # The path IS the download URL
            LOG('download_album: Found Plex direct URL with part ID: {0}'.format(plex_id), xbmc.LOGINFO)
        else:
            # Try to find the track in Plex by searching
            LOG('download_album: No plex_id in path, searching Plex...', xbmc.LOGINFO)
            plex_track = get_plex_track_by_path(file_path)
            if plex_track:
                plex_id = plex_track.get('plex_id')
                download_url = plex_track.get('download_url')
                LOG('download_album: Found track in Plex with ID: {0}'.format(plex_id), xbmc.LOGINFO)
            else:
                LOG('download_album: Could not find track in Plex, skipping: {0}'.format(file_path), xbmc.LOGWARNING)
                skipped_count += 1
                continue
        
        song_info = {
            'path': download_url if download_url else file_path,
            'title': song['title'],
            'plex_id': plex_id,
            'type': 'song',
            'track': song.get('track', 0),
            'artist': song.get('artist', ['Unknown'])[0] if song.get('artist') else 'Unknown',
            'album': song.get('album', 'Unknown'),
            'album_id': album_id
        }
        
        if download_single_item(song_info, show_notifications=False):
            success_count += 1
        else:
            fail_count += 1
    
    # Progress notifications handled in loop
    
    message = 'Downloaded: {0}, Failed: {1}'.format(success_count, fail_count)
    if skipped_count > 0:
        message += ', Skipped: {0}'.format(skipped_count)
    
    show_system_notification(
        'Album Download Complete',
        message
    )
    
    return True


def download_artist(artist_name):
    """Download all songs by an artist"""
    songs = get_artist_songs(artist_name)
    
    LOG('download_artist: Found {0} songs for artist "{1}"'.format(len(songs) if songs else 0, artist_name), xbmc.LOGINFO)
    
    if not songs:
        show_system_notification(
            'PlexKodiConnect Download',
            'No songs found for artist'
        )
        return False
    
    confirm = xbmcgui.Dialog().yesno(
        'Download Artist',
        'Download all {0} songs by "{1}"?'.format(len(songs), artist_name)
    )
    
    if not confirm:
        return False
    
    success_count = 0
    fail_count = 0
    skipped_count = 0
    
    # Show progress via system notifications instead of dialog
    show_system_notification('Downloading Artist', 'Starting download of {0} songs...'.format(len(songs)))
    
    for idx, song in enumerate(songs):
        # Show progress notification every 10 songs or for first/last
        if idx == 0 or idx == len(songs) - 1 or (idx + 1) % 10 == 0:
            overall_percent = int((idx / len(songs)) * 100)
            show_system_notification(
                'Artist Download Progress', 
                'Song {0} of {1}: {2} ({3}%)'.format(
                    idx + 1, len(songs), song.get('title', 'Unknown'), overall_percent
                )
            )
        
        file_path = song.get('file', '')
        LOG('download_artist: Processing song "{0}" with path: {1}'.format(song.get('title', 'Unknown'), file_path), xbmc.LOGINFO)
        
        # Check if this is already a Plex direct download URL
        # Format: https://xxx.plex.direct:32400/library/parts/12345/...
        plex_direct_match = re.search(r'plex\.direct.*?/library/parts/(\d+)/', file_path)
        
        plex_id = None
        download_url = None
        
        # Extract plex_id from song file path (plugin style)
        plex_id_match = re.search(r'plex_id=(\d+)', file_path)
        
        if plex_id_match:
            plex_id = plex_id_match.group(1)
        elif plex_direct_match:
            # This is already a direct Plex download URL - use it directly
            plex_id = plex_direct_match.group(1)  # Use part ID as identifier
            download_url = file_path  # The path IS the download URL
            LOG('download_artist: Found Plex direct URL with part ID: {0}'.format(plex_id), xbmc.LOGINFO)
        else:
            # Try to find the track in Plex by searching
            LOG('download_artist: No plex_id in path, searching Plex...', xbmc.LOGINFO)
            plex_track = get_plex_track_by_path(file_path)
            if plex_track:
                plex_id = plex_track.get('plex_id')
                download_url = plex_track.get('download_url')
                LOG('download_artist: Found track in Plex with ID: {0}'.format(plex_id), xbmc.LOGINFO)
            else:
                LOG('download_artist: Could not find track in Plex, skipping: {0}'.format(file_path), xbmc.LOGWARNING)
                skipped_count += 1
                continue
        
        song_info = {
            'path': download_url if download_url else file_path,
            'title': song['title'],
            'plex_id': plex_id,
            'type': 'song',
            'track': song.get('track', 0),
            'artist': song.get('artist', ['Unknown'])[0] if song.get('artist') else 'Unknown',
            'album': song.get('album', 'Unknown'),
            'album_id': song.get('albumid')
        }
        
        if download_single_item(song_info, show_notifications=False):
            success_count += 1
        else:
            fail_count += 1
    
    # Progress notifications handled in loop
    
    message = 'Downloaded: {0}, Failed: {1}'.format(success_count, fail_count)
    if skipped_count > 0:
        message += ', Skipped: {0}'.format(skipped_count)
    
    show_system_notification(
        'Artist Download Complete',
        message
    )
    
    return True


def download_single_item(item_info, show_notifications=True):
    """Download a single movie or episode from Plex to local storage"""
    
    # Get download directory
    download_path = getDownloadPath()
    
    if not download_path:
        LOG("No download path selected", xbmc.LOGERROR)
        return False
    
    # Check if download directory exists and is writable
    if not xbmcvfs.exists(download_path):
        LOG("Download directory does not exist!", xbmc.LOGERROR)
        if show_notifications:
            show_system_notification(
                'PlexKodiConnect Download',
                'Download path does not exist'
            )
        return False
    
    # Test if directory is writable
    LOG("Checking if destination path {0} is writeable".format(download_path), xbmc.LOGINFO)
    test_file = os.path.join(download_path, "koditmp.txt")
    f = xbmcvfs.File(test_file, 'w')
    writeconfirm = f.write(str("1"))
    f.close()
    
    if writeconfirm:
        xbmcvfs.delete(test_file)
        LOG("Destination path is writeable", xbmc.LOGINFO)
    else:
        LOG("Destination path not writeable", xbmc.LOGERROR)
        if show_notifications:
            show_system_notification(
                'PlexKodiConnect Download',
                'Download path is not writeable'
            )
        return False
    
    # Organize by type if setting is enabled
    organize_by_type = addon.getSetting('organize_by_type') == 'true'
    if organize_by_type:
        media_type = item_info.get('type', 'movie')
        if media_type == 'episode':
            download_path = os.path.join(download_path, 'TV Shows')
        elif media_type == 'song':
            download_path = os.path.join(download_path, 'Music')
        else:
            download_path = os.path.join(download_path, 'Movies')
        
        if not xbmcvfs.exists(download_path):
            xbmcvfs.mkdirs(download_path)
    
    # Sanitize filename
    safe_title = "".join(c for c in item_info['title'] if c.isalnum() or c in (' ', '-', '_', '.'))
    
    # For music, try to get album info if we don't have it yet
    if item_info['type'] == 'song' and item_info.get('song_id') and not item_info.get('album'):
        query = {
            "jsonrpc": "2.0",
            "method": "AudioLibrary.GetSongDetails",
            "params": {
                "songid": item_info['song_id'],
                "properties": ["album", "artist", "track"]
            },
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(query))
        result = json.loads(response)
        if 'result' in result and 'songdetails' in result['result']:
            details = result['result']['songdetails']
            item_info['album'] = details.get('album', 'Unknown Album')
            if not item_info.get('artist'):
                artists = details.get('artist', ['Unknown Artist'])
                item_info['artist'] = artists[0] if artists else 'Unknown Artist'
            if not item_info.get('track') and details.get('track'):
                item_info['track'] = details.get('track', 0)
            LOG('Retrieved album info from Kodi: {0}'.format(item_info['album']), xbmc.LOGINFO)
    
    # Format filename for TV episodes
    if item_info['type'] == 'episode':
        season = item_info.get('season', 0)
        episode = item_info.get('episode', 0)
        
        # Try to extract episode info from title if it contains format like "9x18. Title" or "9x18 - Title"
        title_ep_match = re.search(r'(\d+)x(\d+)[.\s-]+(.+)', item_info['title'])
        if title_ep_match:
            # Use episode info from title
            season = int(title_ep_match.group(1))
            episode = int(title_ep_match.group(2))
            clean_title = title_ep_match.group(3).strip()
            safe_title = "".join(c for c in clean_title if c.isalnum() or c in (' ', '-', '_', '.'))
        
        filename = "S{0:02d}E{1:02d} - {2}".format(season, episode, safe_title)
    elif item_info['type'] == 'song':
        # Format for music: "01 - Song Title"
        track = item_info.get('track', 0)
        if track > 0:
            filename = "{0:02d} - {1}".format(track, safe_title)
        else:
            filename = safe_title
    else:
        # Format for movies
        year = item_info.get('year', '')
        if year:
            filename = "{0} ({1})".format(safe_title, year)
        else:
            filename = safe_title
    
    # Determine source path
    source_path = item_info['path']
    metadata = None
    
    # If it's a plugin path, try to get the direct stream URL and metadata
    if source_path.startswith('plugin://') and item_info.get('plex_id'):
        LOG('Plugin path detected, getting direct stream URL', xbmc.LOGINFO)
        plex_data = get_plex_metadata(item_info['plex_id'])
        
        if plex_data and isinstance(plex_data, dict):
            # For music tracks, we get enhanced metadata
            if plex_data.get('type') == 'track':
                metadata = plex_data
                source_path = plex_data.get('download_url')
                
                # Update item_info with better metadata from Plex
                if metadata.get('artist'):
                    item_info['artist'] = metadata['artist']
                if metadata.get('album'):
                    item_info['album'] = metadata['album']
                if metadata.get('track'):
                    item_info['track'] = int(metadata['track'])
                if metadata.get('title'):
                    item_info['title'] = metadata['title']
                
                # Force type to be song if we got track metadata
                item_info['type'] = 'song'
                
                LOG('Updated with Plex music metadata: {0}'.format(metadata), xbmc.LOGINFO)
            elif plex_data.get('download_url'):
                source_path = plex_data['download_url']
                LOG('Using Plex download URL', xbmc.LOGINFO)
        
        if not source_path or source_path.startswith('plugin://'):
            if show_notifications:
                show_system_notification(
                    'PlexKodiConnect Download',
                    'Could not get download URL. Check PlexKodiConnect settings.'
                )
            return False
    
    # Get file extension from source (before query parameters)
    base_path = source_path.split('?')[0]  # Remove query parameters
    ext = os.path.splitext(base_path)[1].lower()
    
    # Handle various audio/video formats
    if item_info['type'] == 'song' or item_info['type'] == 'music':
        # For music, keep original format but map to common extensions
        if ext in ['.m4a', '.m4b', '.aac']:
            ext = '.m4a'  # Keep m4a for Apple formats
        elif ext in ['.flac', '.wav', '.ogg']:
            ext = ext  # Keep lossless formats as-is
        elif not ext or ext not in ['.mp3', '.m4a', '.flac', '.wav', '.ogg']:
            ext = '.mp3'  # Default to mp3 for unknown audio
    elif ext == '.ts':
        ext = '.mp4'  # Convert transport streams to mp4
    elif not ext:
        ext = '.mp4'  # Default for video
    
    # For music, organize into Artist/Album folders if enabled
    if item_info['type'] == 'song':
        organize_music = addon.getSetting('organize_music') == 'true'
        if organize_music:
            artist_name = item_info.get('artist', 'Unknown Artist')
            album_name = item_info.get('album', 'Unknown Album')
            
            safe_artist = "".join(c for c in artist_name if c.isalnum() or c in (' ', '-', '_', '.'))
            safe_album = "".join(c for c in album_name if c.isalnum() or c in (' ', '-', '_', '.'))
            
            # Create: Music/Artist/Album/
            artist_path = os.path.join(download_path, safe_artist)
            album_path = os.path.join(artist_path, safe_album)
            
            if not xbmcvfs.exists(artist_path):
                xbmcvfs.mkdirs(artist_path)
            if not xbmcvfs.exists(album_path):
                xbmcvfs.mkdirs(album_path)
            
            download_path = album_path
    
    # For TV shows, organize into show/season folders if enabled
    elif item_info['type'] == 'episode':
        organize_tvshows = addon.getSetting('organize_tvshows') == 'true'
        if organize_tvshows:
            # Get show name from JSON-RPC
            query = {
                "jsonrpc": "2.0",
                "method": "VideoLibrary.GetTVShowDetails",
                "params": {
                    "tvshowid": item_info.get('tvshow_id'),
                    "properties": ["title"]
                },
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            
            if 'result' in result and 'tvshowdetails' in result['result']:
                show_title = result['result']['tvshowdetails'].get('title', 'Unknown')
                safe_show_title = "".join(c for c in show_title if c.isalnum() or c in (' ', '-', '_', '.'))
                season_num = item_info.get('season', 1)
                
                # Create: TV Shows/Show Name/Season 1/
                show_path = os.path.join(download_path, safe_show_title)
                season_path = os.path.join(show_path, 'Season {0}'.format(season_num))
                
                if not xbmcvfs.exists(show_path):
                    xbmcvfs.mkdirs(show_path)
                if not xbmcvfs.exists(season_path):
                    xbmcvfs.mkdirs(season_path)
                
                download_path = season_path
    
    dest_filename = filename + ext
    dest_file = os.path.join(download_path, dest_filename)
    
    # Check if file already exists
    if xbmcvfs.exists(dest_file):
        LOG("File already exists: {0}".format(dest_filename), xbmc.LOGINFO)
        
        # For batch downloads, skip existing files
        if not show_notifications:
            return True
        
        # Ask user if they want to redownload existing file
        redrawn = xbmcgui.Dialog().yesno(
            'File Already Exists',
            '{0} already exists.[CR]Do you want to redownload and overwrite?'.format(dest_filename),
            nolabel='Skip',
            yeslabel='Redownload'
        )
        
        if not redrawn:
            LOG("File already exists, user chose to skip", xbmc.LOGINFO)
            return True
        
        LOG("File already exists, user chose to redownload", xbmc.LOGINFO)
    
    # Show persistent notification for single downloads
    if show_notifications:
        show_persistent_notification(
            'Downloading',
            '{0} - 0%'.format(item_info["title"])
        )
    
    # Notify if playing (only for single downloads)
    if show_notifications and xbmc.Player().isPlaying():
        show_persistent_notification(
            'Downloading',
            '{0} - 0%'.format(item_info['title'])
        )
    
    # Show progress via system notification instead of dialog
    show_system_notification('PlexKodiConnect Download', 'Preparing to download {0}...'.format(item_info["title"]))
    
    try:
        # Copy file with progress (no progress dialog for single items)
        success = copy_with_progress(source_path, dest_file, item_info["title"], None)
        
        xbmc.sleep(500)
        
        if success:
            # Write metadata NFO file
            write_metadata = addon.getSetting('write_metadata') == 'true'
            if write_metadata:
                # Get full metadata from Plex if we have a plex_id
                plex_metadata = None
                if item_info.get('plex_id'):
                    plex_metadata = get_plex_full_metadata(item_info['plex_id'])
                write_nfo_file(dest_file, item_info, metadata, plex_metadata)
            
            if show_notifications:
                show_system_notification(
                    'Download Complete',
                    '{0} saved successfully!'.format(item_info["title"])
                )
                
                # Auto-play the downloaded file if setting is enabled
                auto_play_setting = addon.getSetting('auto_play') == 'true'
                if auto_play_setting:
                    show_system_notification(
                        'Auto-playing',
                        'Playing {0}'.format(item_info["title"])
                    )
                    xbmc.Player().play(dest_file)
            
            return True
        else:
            if show_notifications:
                show_system_notification(
                    'Download Failed',
                    'Could not download file from Plex'
                )
            return False
    
    except Exception as e:
        LOG("Download error: {0}".format(str(e)), xbmc.LOGERROR)
        if show_notifications:
            show_system_notification(
                'Download Error',
                str(e)
            )
        return False


def download_from_plex():
    """Main entry point - download movie, TV show, or music from Plex"""
    
    item_info = get_plex_item_info()
    
    if not item_info:
        show_system_notification(
            'PlexKodiConnect Download',
            'Could not retrieve Plex item information'
        )
        return False
    
    # Handle TV show directory (download entire show or select seasons)
    if item_info['type'] == 'tvshow' and item_info.get('tvshow_id'):
        tvshow_id = item_info['tvshow_id']
        show_title = item_info.get('title', 'Unknown Show')
        
        # Get available seasons
        seasons = get_tvshow_seasons(tvshow_id)
        
        if not seasons:
            xbmcgui.Dialog().notification(
                'PlexKodiConnect Download',
                'No seasons found for this show',
                os.path.join(addonFolder, "icon.png"),
                5000,
                True
            )
            return False
        
        # Check settings for unwatched options
        show_unwatched = addon.getSetting('show_unwatched_options') == 'true'
        unwatched_count = count_unwatched_in_show(tvshow_id) if show_unwatched else 0
        
        # Get unwatched option values from settings (0 means disabled)
        unwatched_opt1 = int(addon.getSetting('unwatched_option_1') or '1')
        unwatched_opt2 = int(addon.getSetting('unwatched_option_2') or '5')
        unwatched_opt3 = int(addon.getSetting('unwatched_option_3') or '10')
        
        # Build options list
        options = ['Download entire show ({0} seasons)'.format(len(seasons))]
        option_actions = [('show', None)]
        
        # Add unwatched options if enabled and there are unwatched episodes
        if show_unwatched and unwatched_count > 0:
            if unwatched_opt1 > 0 and unwatched_count >= unwatched_opt1:
                options.append('Download next {0} unwatched'.format(unwatched_opt1))
                option_actions.append(('unwatched', unwatched_opt1))
            if unwatched_opt2 > 0 and unwatched_count >= unwatched_opt2:
                options.append('Download next {0} unwatched'.format(unwatched_opt2))
                option_actions.append(('unwatched', unwatched_opt2))
            if unwatched_opt3 > 0 and unwatched_count >= unwatched_opt3:
                options.append('Download next {0} unwatched'.format(unwatched_opt3))
                option_actions.append(('unwatched', unwatched_opt3))
            options.append('Download all {0} unwatched'.format(unwatched_count))
            option_actions.append(('unwatched', None))
        
        for season in seasons:
            season_num = season.get('season', 0)
            episode_count = season.get('episode', 0)
            if season_num == 0:
                options.append('Specials ({0} episodes)'.format(episode_count))
            else:
                options.append('Season {0} ({1} episodes)'.format(season_num, episode_count))
            option_actions.append(('season', season_num))
        
        choice = xbmcgui.Dialog().select('Download "{0}"'.format(show_title), options)
        
        if choice == -1:  # User cancelled
            return False
        
        action, value = option_actions[choice]
        if action == 'show':
            return download_show(tvshow_id)
        elif action == 'unwatched':
            episodes = get_unwatched_episodes_in_show(tvshow_id, value)
            return download_episodes(episodes, tvshow_id, 'Downloading Unwatched')
        elif action == 'season':
            return download_season(tvshow_id, value)
    
    # Handle season directory (download entire season or select episodes)
    elif item_info['type'] == 'season' and item_info.get('tvshow_id'):
        tvshow_id = item_info['tvshow_id']
        season_num = item_info['season']
        show_title = item_info.get('show_title', 'Unknown Show')
        
        # Get episodes in this season
        episodes = get_season_episodes(tvshow_id, season_num)
        
        if not episodes:
            xbmcgui.Dialog().notification(
                'PlexKodiConnect Download',
                'No episodes found in this season',
                os.path.join(addonFolder, "icon.png"),
                5000,
                True
            )
            return False
        
        # Build options
        if season_num == 0:
            season_label = 'Specials'
        else:
            season_label = 'Season {0}'.format(season_num)
        
        # Check settings
        show_download_season = addon.getSetting('show_download_season_from_season') == 'true'
        show_download_show = addon.getSetting('show_download_show_from_season') == 'true'
        show_unwatched = addon.getSetting('show_unwatched_options') == 'true'
        show_all_unwatched = addon.getSetting('show_all_unwatched_option') == 'true'
        unwatched_count = count_unwatched_in_season(tvshow_id, season_num) if show_unwatched else 0
        
        # Get unwatched option values from settings (0 means disabled)
        unwatched_opt1 = int(addon.getSetting('unwatched_option_1') or '1')
        unwatched_opt2 = int(addon.getSetting('unwatched_option_2') or '5')
        unwatched_opt3 = int(addon.getSetting('unwatched_option_3') or '10')
        
        options = []
        option_actions = []
        
        # Add download entire season option if enabled
        if show_download_season:
            options.append('Download entire {0} ({1} episodes)'.format(season_label, len(episodes)))
            option_actions.append(('season', None))
        
        # Add unwatched options if enabled and there are unwatched episodes
        if show_unwatched and unwatched_count > 0:
            if unwatched_opt1 > 0 and unwatched_count >= unwatched_opt1:
                options.append('Download next {0} unwatched'.format(unwatched_opt1))
                option_actions.append(('unwatched_season', unwatched_opt1))
            if unwatched_opt2 > 0 and unwatched_count >= unwatched_opt2:
                options.append('Download next {0} unwatched'.format(unwatched_opt2))
                option_actions.append(('unwatched_season', unwatched_opt2))
            if unwatched_opt3 > 0 and unwatched_count >= unwatched_opt3:
                options.append('Download next {0} unwatched'.format(unwatched_opt3))
                option_actions.append(('unwatched_season', unwatched_opt3))
            if show_all_unwatched:
                options.append('Download all {0} unwatched in season'.format(unwatched_count))
                option_actions.append(('unwatched_season', None))
        
        if show_download_show:
            options.append('Download entire show')
            option_actions.append(('show', None))
        
        # Make sure at least one option is available
        if len(options) == 0:
            # Force show the season download option
            options.append('Download entire {0} ({1} episodes)'.format(season_label, len(episodes)))
            option_actions.append(('season', None))
        
        # If only one option, skip the dialog and execute directly
        if len(options) == 1:
            action, value = option_actions[0]
            if action == 'season':
                return download_season(tvshow_id, season_num)
            elif action == 'unwatched_season':
                eps = get_unwatched_episodes_in_season(tvshow_id, season_num, value)
                return download_episodes(eps, tvshow_id, 'Downloading Unwatched')
            elif action == 'show':
                return download_show(tvshow_id)
        
        choice = xbmcgui.Dialog().select('Download "{0}" - {1}'.format(show_title, season_label), options)
        
        if choice == -1:  # User cancelled
            return False
        
        action, value = option_actions[choice]
        if action == 'season':
            return download_season(tvshow_id, season_num)
        elif action == 'unwatched_season':
            episodes = get_unwatched_episodes_in_season(tvshow_id, season_num, value)
            return download_episodes(episodes, tvshow_id, 'Downloading Unwatched')
        elif action == 'show':
            return download_show(tvshow_id)
    
    # For TV episodes, offer options to download episode, season, or entire show
    elif item_info['type'] == 'episode' and item_info.get('tvshow_id'):
        # Check settings for menu options
        show_season_option = addon.getSetting('show_download_season_from_episode') == 'true'
        show_show_option = addon.getSetting('show_download_show_from_episode') == 'true'
        
        options = ['Download this episode']
        season_idx = -1
        show_idx = -1
        
        if show_season_option and item_info.get('season') is not None:
            options.append('Download entire season {0}'.format(item_info['season']))
            season_idx = len(options) - 1
        
        if show_show_option:
            options.append('Download entire show')
            show_idx = len(options) - 1
        
        # If only one option, skip the dialog and download directly
        if len(options) == 1:
            return download_single_item(item_info)
        
        choice = xbmcgui.Dialog().select('Download Options', options)
        
        if choice == -1:  # User cancelled
            return False
        elif choice == 0:  # Single episode
            return download_single_item(item_info)
        elif choice == season_idx:  # Season
            return download_season(item_info['tvshow_id'], item_info['season'])
        elif choice == show_idx:  # Entire show
            return download_show(item_info['tvshow_id'])
    
    # Handle artist directory (download entire artist discography)
    elif item_info['type'] == 'artist' and item_info.get('artist'):
        artist_name = item_info['artist']
        return download_artist(artist_name)
    
    # Handle album directory (download entire album or artist)
    elif item_info['type'] == 'album' and item_info.get('album_id'):
        album_id = item_info['album_id']
        album_title = item_info.get('title', 'Unknown Album')
        artist_name = item_info.get('artist')
        
        # Check setting for showing "Download entire artist" option
        show_artist_option = addon.getSetting('show_download_artist_from_album') == 'true'
        
        options = ['Download entire album']
        
        if show_artist_option and artist_name:
            options.append('Download all by {0}'.format(artist_name))
        
        # If only one option, skip the dialog and download the album directly
        if len(options) == 1:
            return download_album(album_id, album_title)
        
        choice = xbmcgui.Dialog().select('Download "{0}"'.format(album_title), options)
        
        if choice == -1:  # User cancelled
            return False
        elif choice == 0:  # Entire album
            return download_album(album_id, album_title)
        elif choice == 1:  # Entire artist
            return download_artist(artist_name)
    
    # For music, offer options to download song, album, or artist
    elif item_info['type'] == 'song':
        # Check settings for menu options
        show_album_option = addon.getSetting('show_download_album_from_song') == 'true'
        show_artist_option = addon.getSetting('show_download_artist_from_song') == 'true'
        
        options = ['Download this song']
        album_idx = -1
        artist_idx = -1
        
        if show_album_option and item_info.get('album_id'):
            options.append('Download entire album')
            album_idx = len(options) - 1
        
        # Get artist name from JSON-RPC
        if show_artist_option and item_info.get('song_id'):
            query = {
                "jsonrpc": "2.0",
                "method": "AudioLibrary.GetSongDetails",
                "params": {
                    "songid": item_info['song_id'],
                    "properties": ["artist"]
                },
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(query))
            result = json.loads(response)
            if 'result' in result and 'songdetails' in result['result']:
                artists = result['result']['songdetails'].get('artist', [])
                if artists:
                    item_info['artist'] = artists[0]
                    options.append('Download all by {0}'.format(artists[0]))
                    artist_idx = len(options) - 1
        
        # If only one option, skip the dialog and download directly
        if len(options) == 1:
            return download_single_item(item_info)
        
        choice = xbmcgui.Dialog().select('Download Options', options)
        
        if choice == -1:  # User cancelled
            return False
        elif choice == 0:  # Single song
            return download_single_item(item_info)
        elif choice == album_idx:  # Album
            # Get album name
            if item_info.get('song_id'):
                query = {
                    "jsonrpc": "2.0",
                    "method": "AudioLibrary.GetSongDetails",
                    "params": {
                        "songid": item_info['song_id'],
                        "properties": ["album"]
                    },
                    "id": 1
                }
                response = xbmc.executeJSONRPC(json.dumps(query))
                result = json.loads(response)
                if 'result' in result and 'songdetails' in result['result']:
                    album_name = result['result']['songdetails'].get('album', 'Unknown')
                    return download_album(item_info['album_id'], album_name)
            return download_album(item_info['album_id'])
        elif choice == artist_idx:  # Artist
            return download_artist(item_info.get('artist', 'Unknown'))
    
    else:
        # For movies, just download directly
        return download_single_item(item_info)


if __name__ == '__main__':
    # Check if we're being called with a specific action (from settings)
    if len(sys.argv) > 1:
        action = sys.argv[1]
        if action == 'delete_movies':
            delete_downloads_by_type('movies')
        elif action == 'delete_tvshows':
            delete_downloads_by_type('tvshows')
        elif action == 'delete_music':
            delete_downloads_by_type('music')
        else:
            download_from_plex()
    else:
        download_from_plex()
