ebhook Runner Add-on for Kodi 21+

This addon allows you to trigger Home Assistant webhooks from Kodi.

Features:
 - Up to 10 configurable webhooks
 - Each with a custom name and URL
 - Optional notification toggle
 - Works from remote buttons and GUI

To launch from remote:
  <red>RunScript("script.webhook.runner", id=1)</red>

To launch from GUI:
  Go to Add-ons → Program Add-ons → Webhook Runner
