"""Background service: the licence relay, and telling Starz how a playback went.

* lib/license_relay.py: localhost relay ISA sends licence requests to.

The plugin process ends as soon as playback starts, so a service is the only
place that can still talk to Starz while a title plays and when it stops:

* Play/update every 30 s, as the website does (keep-alive HAR), with the
  current position.
* Play/stop with the final position when playback ends -- this is what puts
  the resume point into Continue Watching on Starz's own apps, and closes the
  session rather than leaving it to look like it is still playing.

default.py writes the session (content id, playbackSessionId, manifest URL)
to PLAYING_FILE just before resolving the stream; the service only reports
for a playing file that matches it, so other addons' playback is ignored.
"""

import threading
import time

import xbmc

from lib import kodiutils
from lib.api import StarzApi, PLAYING_FILE
from lib.auth import StarzAuth
from lib.license_relay import LicenseRelay
from lib import upnext
from skipbuttons import SkipController
from lib import programme
from lib.channels import NAMES
from lib.api import to_item

# The website reports every 20-30 s (keep-alive HAR), well inside the 600 s
# keep-alive Starz gives; doing the same keeps the resume point current.
UPDATE_SECS = 30
LIVE_DELAY_SECS = 25
POLL_SECS = 1


def skip_markers(content):
    """The markers script.module.skipbuttons takes, from a Starz title's
    detail (v8/content): "recap"/"intro": {"timeIn", "timeOut"} and
    "creditTimeIn", in seconds (e.g. Power S1E2: recap 10-61, intro 62-152,
    credits 3432)."""
    def num(value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    out = {}
    runtime = num(content.get("runtime"))
    for name in ("recap", "intro"):
        seg = content.get(name) or {}
        t_in, t_out = num(seg.get("timeIn")), num(seg.get("timeOut"))
        if t_in is not None and t_out and t_out - t_in >= 5:
            out[name] = (t_in, t_out)
    credits = num(content.get("creditTimeIn"))
    # Not a credits time at (or past) the very end (previews: = runtime).
    if credits and credits > 60 and (not runtime or credits < runtime - 5):
        out["credits"] = credits
    return out


class Session(object):
    def __init__(self, info):
        self.info = info
        self.position = 0.0
        self.last_update = None   # set on the first tick: the start
        self.next_id = None       # the next episode, once looked up


class Player(xbmc.Player):

    def __init__(self):
        xbmc.Player.__init__(self)
        self.session = None
        # Skip recap / Skip intro / Next episode (script.module.skipbuttons).
        self.skip = SkipController(
            self, self._play_next,
            autoplay=lambda: kodiutils.get_setting_bool("autoplay_next", True))

    def _play_next(self):
        next_id = self.session.next_id if self.session else None
        if not next_id:
            return
        self._finish()            # Play/stop for this episode first
        kodiutils.log("Playing next episode %s" % next_id)
        xbmc.executebuiltin("PlayMedia(plugin://plugin.video.starz/?action=play&content_id=%s)"
                            % next_id)

    def onAVStarted(self):
        info = kodiutils.read_json(PLAYING_FILE, default=None)
        if not info:
            return
        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            return
        if info.get("manifest_url") and info["manifest_url"] not in playing:
            return
        kodiutils.delete_file(PLAYING_FILE)
        self._finish()   # a previous title that never reported stopping
        self.session = Session(info)
        if info.get("live"):
            # Live (second live HAR): Play/update every 30 s with contentId 2
            # and the wall-clock time as the position, Play/stop with "2" and
            # 0. No next episode and nothing to seek.
            if info.get("report_id"):
                info["content_id"] = info["report_id"]
            kodiutils.log("Playing the live stream")
            return
        kodiutils.log("Tracking Starz playback of %s" % info.get("content_id"))
        # Off the callback thread: two metadata requests.
        threading.Thread(target=self._prepare_next, args=(self.session,)).start()
        if info.get("seek_to"):
            # Tuning in to a channel: jump to where its schedule has reached.
            try:
                self.seekTime(float(info["seek_to"]))
                kodiutils.log("Tuned in at %ds" % int(info["seek_to"]))
            except RuntimeError as exc:
                kodiutils.log_error("Seek failed: %s" % exc)

    def tick(self, now):
        """Called every POLL_SECS by the service loop while a session runs."""
        if not self.session:
            return
        try:
            if self.session.info.get("live"):
                # What the website sends for live: the time now, minus the
                # manifest's suggested presentation delay (25 s).
                self.session.position = time.time() - LIVE_DELAY_SECS
            elif self.isPlayingVideo():
                self.session.position = self.getTime()
        except RuntimeError:
            return
        if self.session.last_update is None:
            self.session.last_update = now
        elif now - self.session.last_update >= UPDATE_SECS:
            self._report("update")
            self.session.last_update = now
        self._follow_schedule()
        if not self.session.info.get("live"):
            self.skip.tick(self.session.position, now)

    def _follow_schedule(self):
        """Live: when the airing programme ends, put the next one's title,
        plot and artwork on the player (Player.updateInfoTag, Kodi 20+)."""
        info = self.session.info if self.session else {}
        if not info.get("live") or not info.get("channel"):
            return
        end = info.get("programme_end") or 0
        if time.time() * 1000 < end:
            return
        if time.time() - self.session.__dict__.get("schedule_checked", 0) < 30:
            return            # at most one look-up every 30 s
        self.session.schedule_checked = time.time()
        try:
            el = StarzApi(StarzAuth()).on_now(info["channel"])
            if not el:
                return
            info["programme_end"] = el.get("endMs") or 0
            self.updateInfoTag(programme.listitem(el, NAMES.get(info["channel"], "")))
            kodiutils.log("Live now: %s" % el.get("title"))
        except Exception as exc:
            kodiutils.log_error("Live programme update failed: %s" % exc)

    def _report(self, kind):
        s = self.session
        if not s or not s.info.get("session_id"):
            return
        try:
            StarzApi(StarzAuth()).report_play(kind, s.info["content_id"],
                                              s.info["session_id"], s.position)
            kodiutils.log("Play/%s sent at %ds" % (kind, int(s.position)))
        except Exception as exc:
            kodiutils.log_error("Play/%s failed: %s" % (kind, exc))

    def _finish(self):
        self.skip.reset()
        if self.session and self.session.info.get("live"):
            self.session.position = 0     # the website stops live with 0
        if self.session:
            self._report("stop")
            self.session = None

    def onPlayBackStopped(self):
        self._finish()

    def _prepare_next(self, session):
        """For an episode: find the next one, hand both to Up Next if it is
        installed, and remember it for the built-in autoplay otherwise."""
        try:
            api = StarzApi(StarzAuth())
            current = api.title_detail(session.info["content_id"])
            marks = skip_markers(current)
            nxt = cur_item = next_item = None
            if current.get("contentType") == "Episode" and current.get("nextContentId"):
                nxt = api.title_detail(current["nextContentId"])
                cur_item, next_item = to_item(current), to_item(nxt)
            if session is not self.session:
                return                # playback moved on meanwhile
            session.next_id = next_item["id"] if cur_item and next_item else None
            self.skip.reset(marks, has_next=bool(session.next_id),
                            credits=not upnext.installed())
            kodiutils.log("Markers %s, next episode %s" % (marks, session.next_id))
            if not session.next_id:
                return
            if upnext.installed():
                upnext.signal(upnext.build(cur_item, current, next_item, nxt))
                kodiutils.log("Up Next: next episode %s, pop-up at %ss" % (
                    next_item["id"], current.get("creditTimeIn")))
            else:
                kodiutils.log("Next episode %s (autoplay %s)" % (
                    next_item["id"], "on" if kodiutils.get_setting_bool("autoplay_next", True) else "off"))
        except Exception as exc:
            kodiutils.log_error("Next episode lookup failed: %s" % exc)

    def onPlayBackEnded(self):
        next_id = self.session.next_id if self.session else None
        self._finish()
        # Up Next plays the next episode itself; without it, do it here.
        if next_id and not upnext.installed() and kodiutils.get_setting_bool("autoplay_next", True):
            kodiutils.log("Autoplaying next episode %s" % next_id)
            xbmc.executebuiltin("PlayMedia(plugin://plugin.video.starz/?action=play&content_id=%s)"
                                % next_id)

    def onPlayBackError(self):
        self._finish()


def run():
    monitor = xbmc.Monitor()
    relay = LicenseRelay()
    relay.start()
    player = Player()
    clock = 0.0
    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(POLL_SECS):
                break
            clock += POLL_SECS
            player.tick(clock)
        player._finish()
    finally:
        try:
            relay.stop()
        except Exception as exc:   # e.g. the add-on is mid-update
            xbmc.log("[plugin.video.starz] relay stop: %s" % exc, xbmc.LOGINFO)


if __name__ == "__main__":
    run()
