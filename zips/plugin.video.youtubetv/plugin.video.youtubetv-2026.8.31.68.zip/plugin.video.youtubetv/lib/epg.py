"""Turning InnerTube renderers into channels and programmes.

The EPG response is a deep tree of ``*Renderer`` dicts with the interesting
values scattered through it. Rather than walk fixed paths -- which break the
first time Google inserts a wrapper -- everything here searches by key name and
tolerates absence. A missing description is not worth an exception.
"""

import base64
import binascii
import re
import time
from urllib.parse import unquote

from . import kodiutils


def walk(node, key):
    """Yield every value stored under ``key``, at any depth."""
    if isinstance(node, dict):
        for name, value in node.items():
            if name == key:
                yield value
            for found in walk(value, key):
                yield found
    elif isinstance(node, list):
        for value in node:
            for found in walk(value, key):
                yield found


def first(node, key, default=None):
    for value in walk(node, key):
        return value
    return default


def text(node, default=""):
    """Flatten a ``{"runs": [{"text": ...}]}`` or ``{"simpleText": ...}``."""
    if not isinstance(node, dict):
        return default
    if "simpleText" in node:
        return node["simpleText"] or default
    runs = node.get("runs")
    if isinstance(runs, list):
        joined = "".join(run.get("text", "") for run in runs if isinstance(run, dict))
        if joined:
            return joined
    return default


def accessibility_label(node, default=""):
    """The label Google attaches to a thumbnail for screen readers.

    Worth having because some stations come back with ``name`` and ``callSign``
    both null -- the icon's accessibility label is then the only human-readable
    name in the row.
    """
    for block in walk(node, "accessibilityData"):
        if isinstance(block, dict) and block.get("label"):
            return block["label"]
    return default


def thumbnail(node, prefer_width=0):
    """Best thumbnail URL from a ``{"thumbnails": [...]}`` block.

    URLs come back protocol-relative ("//yt3.ggpht.com/..."), which Kodi will
    not fetch, so they are made absolute here.
    """
    thumbs = []
    for block in walk(node, "thumbnails"):
        if isinstance(block, list):
            thumbs.extend(t for t in block if isinstance(t, dict) and t.get("url"))
    if not thumbs:
        return ""
    if prefer_width:
        thumbs.sort(key=lambda t: abs(int(t.get("width") or 0) - prefer_width))
    else:
        thumbs.sort(key=lambda t: int(t.get("width") or 0), reverse=True)
    url = thumbs[0]["url"]
    if url.startswith("//"):
        url = "https:" + url
    return url


def is_portrait(node):
    """Whether a thumbnail block is taller than it is wide.

    A film's tile is a poster -- 2560x3840 -- and belongs in the slot a
    skin keeps for one. A show's is a wide still, and putting that in the
    same slot is what made Marshals look stretched. Only the shape says
    which, so it is asked rather than assumed.
    """
    for block in walk(node, "thumbnails"):
        if not isinstance(block, list):
            continue
        for thumb in block:
            if not isinstance(thumb, dict):
                continue
            try:
                wide, tall = int(thumb.get("width") or 0), int(thumb.get("height") or 0)
            except (TypeError, ValueError):
                continue
            if wide and tall:
                return tall > wide
    return False


class Airing(object):
    """One programme on one channel."""

    __slots__ = ("video_id", "title", "description", "start_ms", "end_ms",
                 "art", "on_air", "show_id", "genres", "mpaa", "duration",
                 "season", "episode", "episode_title")

    def __init__(self, video_id, title, description, start_ms, end_ms, art,
                 on_air=False, show_id="", genres=(), mpaa="", duration=0,
                 season=0, episode=0, episode_title=""):
        self.video_id = video_id
        self.title = title
        self.description = description
        self.start_ms = start_ms
        self.end_ms = end_ms
        self.art = art
        # True when the id came from a watchEndpoint rather than the plain
        # videoId field. YouTube TV gives the endpoint to exactly one airing
        # per channel -- the one on the air -- so this is the guide's own
        # word for "now", and worth more than arithmetic on a clock that may
        # not agree with Google's.
        self.on_air = on_air
        # Everything the airing's info panel says about it. An airing
        # renderer itself carries eight keys and none of them is a picture
        # or a synopsis; all of this is one level down, in the panel.
        self.genres = list(genres)
        self.mpaa = mpaa
        self.duration = duration
        self.season = season
        self.episode = episode
        self.episode_title = episode_title
        # The show this programme belongs to, when the guide says. A
        # side-sheet command names both the programme and its show, and the
        # show is what the DVR records -- YouTube TV records a series, not
        # an airing.
        self.show_id = show_id

    @property
    def is_now(self):
        now = time.time() * 1000
        return bool(self.start_ms and self.end_ms
                    and self.start_ms <= now < self.end_ms)

    def label(self):
        if not self.start_ms:
            return self.title
        when = time.strftime("%H:%M", time.localtime(self.start_ms / 1000.0))
        return "%s  %s" % (when, self.title)


class Station(object):
    """One channel, with whatever schedule came back alongside it."""

    __slots__ = ("station_id", "name", "call_sign", "logo", "airings")

    def __init__(self, station_id, name, call_sign, logo, airings):
        self.station_id = station_id
        self.name = name
        self.call_sign = call_sign
        self.logo = logo
        self.airings = airings

    @property
    def now(self):
        # The guide's own marker first, then the clock. YouTube TV gives a
        # watchEndpoint to exactly one airing per channel and it is the one
        # on the air, which beats comparing timestamps against a clock that
        # need not agree with Google's -- run against the 2026-08-29 capture
        # from a later day, is_now picked a different airing on 113 of the
        # 148 stations while the marker was right on all of them.
        #
        # This also keeps what the addon did before the guide carried whole
        # schedules: there was one airing per station, the marked one, and
        # "now" was always it. Falling through to airings[0] now would mean
        # playing whatever was on this morning.
        for airing in self.airings:
            if airing.on_air:
                return airing
        for airing in self.airings:
            if airing.is_now:
                return airing
        return self.airings[0] if self.airings else None

    @property
    def next_up(self):
        now = time.time() * 1000
        upcoming = [a for a in self.airings if a.start_ms and a.start_ms > now]
        upcoming.sort(key=lambda a: a.start_ms)
        return upcoming[0] if upcoming else None


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def parse_airing(renderer):
    """One programme.

    The id is taken from a watchEndpoint if there is one and from the
    renderer's own ``videoId`` field otherwise. Only the programme actually
    on the air carries the endpoint: of the 953 airings in the 2026-08-29
    guide, 144 had one -- one per channel, the one showing now -- and the
    other 809 carried a navigationEndpoint to the show page and their id in
    a plain field beside it. Reading the endpoint alone is why the guide
    listed what was on and nothing after it.
    """
    video_id = ""
    for endpoint in walk(renderer, "watchEndpoint"):
        if isinstance(endpoint, dict) and endpoint.get("videoId"):
            video_id = endpoint["videoId"]
            break
    on_air = bool(video_id)
    if not video_id and isinstance(renderer.get("videoId"), str):
        video_id = renderer["videoId"]
    # Which show this programme belongs to, which is what the DVR records.
    # entitiesDvrStatus names it on every airing, including the one on the
    # air, whose watchEndpoint carries no show id anywhere. Checked against
    # the side-sheet command on the 843 airings that have both: they agree
    # every time, none differ, and this covers the 143 that the side sheet
    # does not. The field carries no state despite its name -- just the id.
    show_id = ""
    status = renderer.get("entitiesDvrStatus")
    if isinstance(status, list) and status and isinstance(status[0], dict):
        found = status[0].get("entityId")
        if isinstance(found, str):
            show_id = found

    for carrier in _ENDPOINT_CARRIERS:
        block = renderer.get(carrier)
        if not isinstance(block, dict):
            continue
        command = block.get("unpluggedGetSidesheetCommand")
        if not isinstance(command, dict):
            continue
        params = command.get("params")
        if not show_id:
            show_id = sidesheet_id(params)
        if not video_id:
            video_id = sidesheet_video_id(params)
        if show_id and video_id:
            break

    title = text(renderer.get("title")) or text(renderer.get("primaryText"))
    description = (text(renderer.get("quaternaryText"))
                   or text(renderer.get("tertiaryText")))
    panel = _airing_panel(renderer)
    return Airing(
        video_id=video_id,
        title=title or "Unknown",
        description=description or panel["description"],
        start_ms=_int(renderer.get("beginTimeMs")),
        end_ms=_int(renderer.get("endTimeMs")),
        # The airing's own thumbnail first, and there has never been one:
        # not one of the 989 airings in the 2026-08-30 guide carries a
        # "thumbnail" key at all. The picture is in the info panel beside
        # it, 2560x1440, on 989 of the 989. That is why the guide was a
        # column of channel logos.
        art=(thumbnail(renderer.get("thumbnail") or {}, prefer_width=1280)
             or panel["art"]),
        on_air=on_air,
        show_id=show_id,
        genres=panel["genres"],
        mpaa=panel["mpaa"],
        duration=panel["duration"],
        season=panel["season"],
        episode=panel["episode"],
        episode_title=panel["episode_title"],
    )


# "2 hr", "1 hr 30 min", "45 min" -- how the guide writes a runtime.
_RUNTIME = re.compile(r"^(?:(\d+)\s*hr)?\s*(?:(\d+)\s*min)?$")


def _written_runtime(part):
    """Seconds out of "2 hr" or "1 hr 30 min", and 0 out of anything else."""
    found = _RUNTIME.match(part.strip())
    if not found or not any(found.groups()):
        return 0
    return int(found.group(1) or 0) * 3600 + int(found.group(2) or 0) * 60


def _airing_panel(renderer):
    """What a guide airing's info panel says about it.

    **This is where the guide keeps everything.** An epgAiringRenderer has
    eight keys -- times, a title, an endpoint, a DVR status -- and not one
    of them is a picture, a synopsis, a genre or a rating. Its
    epgInfoPanelRenderer has all four, on 989 of the 989 airings in the
    2026-08-30 guide:

      * ``thumbnail``          a 2560x1440 still
      * ``primaryContainer``   "KDKA+ * 2 hr * R", or
                               "Sat, Aug 29, 11:00 PM * KDKA+ * Aired Mar 1,
                               2025 * S38 E20 * The Hit-and-Run Homicide of
                               Davis McClendon * TV-14"
      * ``secondaryContainer`` the synopsis
      * ``tertiaryContainer``  "Animated * Sitcom * Comedy"

    The primary line is read part by part rather than by position: it comes
    in two to seven parts, and which parts are present varies by programme.
    Each part is claimed only by something that recognises it, so a channel
    name is never taken for a rating and a date is never taken for a
    runtime.
    """
    found = {"art": "", "description": "", "genres": [], "mpaa": "",
             "duration": 0, "season": 0, "episode": 0, "episode_title": ""}
    panel = first(renderer, "epgInfoPanelRenderer")
    if not isinstance(panel, dict):
        return found
    found["art"] = thumbnail(panel.get("thumbnail") or {}, prefer_width=1280)
    found["description"] = deep_text(panel.get("secondaryContainer"))
    found["genres"] = [part.strip()
                       for part in deep_text(
                           panel.get("tertiaryContainer")).split("\u2022")
                       if part.strip()]
    parts = [part.strip() for part in
             deep_text(panel.get("primaryContainer")).split("\u2022")]
    for index, part in enumerate(parts):
        if not part:
            continue
        numbered = _EPISODE.match(part)
        if numbered:
            found["season"] = int(numbered.group(1))
            found["episode"] = int(numbered.group(2))
            # The part after the numbers is the episode's name. Taken by
            # position only here, where the position is defined by the part
            # before it rather than by counting from the front.
            if index + 1 < len(parts):
                found["episode_title"] = parts[index + 1].strip()
            continue
        if not found["mpaa"] and _RATING.match(part.upper()):
            found["mpaa"] = part
            continue
        if not found["duration"]:
            found["duration"] = _written_runtime(part)
    return found


def deep_text(node):
    """Every string in a small subtree, joined.

    The guide's info panel wraps its lines two renderers deep --
    unpluggedBadgedTextRenderer holding unpluggedTextRenderer holding the
    text -- so text(), which reads one node, reads nothing from it.
    """
    out = []

    def visit(node):
        if isinstance(node, dict):
            if isinstance(node.get("simpleText"), str):
                out.append(node["simpleText"])
                return
            if isinstance(node.get("runs"), list):
                out.append("".join(run.get("text", "") for run in node["runs"]
                                   if isinstance(run, dict)))
                return
            for value in node.values():
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    visit(node)
    return " ".join(out)


def parse_epg(response):
    """Stations, in the order the guide returned them.

    Rows pair a station with its airings, so they are read row by row rather
    than by collecting the two renderer types separately -- that would lose
    which programme belongs to which channel.
    """
    stations = []
    seen = set()

    for row in walk(response, "epgRowRenderer"):
        renderer = first(row, "epgStationRenderer")
        if not isinstance(renderer, dict):
            # A later page of the guide describes each channel once, on the
            # first page, and then sends rows carrying only a stationId and
            # more airings. Requiring the station renderer threw away all
            # 748 airings of the second page. The row still says which
            # channel it is; the name and logo come from the merge.
            station_id = (row.get("stationId") or row.get("tenxId") or ""
                          ) if isinstance(row, dict) else ""
            if not station_id or station_id in seen:
                continue
            seen.add(station_id)
            airings = []
            for block in walk(row, "epgAiringRenderer"):
                if isinstance(block, dict):
                    airing = parse_airing(block)
                    if airing.video_id:
                        airings.append(airing)
            airings.sort(key=lambda a: a.start_ms or 0)
            stations.append(Station(station_id=station_id, name="",
                                    call_sign="", logo="", airings=airings))
            continue
        station_id = renderer.get("stationId") or renderer.get("tenxId") or ""
        if not station_id or station_id in seen:
            continue
        seen.add(station_id)

        airings = []
        for block in walk(row, "epgAiringRenderer"):
            if isinstance(block, dict):
                airing = parse_airing(block)
                if airing.video_id:
                    airings.append(airing)
        airings.sort(key=lambda a: a.start_ms or 0)

        # Searched across the whole station renderer rather than under
        # "icon". Only 7 of the 148 stations in the 2026-08-29 guide carry
        # a name or a callSign at all; the other 141 are named solely by the
        # accessibility label on their logo. Naming the key that logo sits
        # under is therefore the difference between a lineup and 141 rows
        # called UC5M1ACzZ9iIL42YKinxZrFQ -- and a client that files it
        # under any other key loses the name and the logo together, which is
        # what "mostly missing station names and no logos" looks like.
        # "icon" is still preferred where it exists -- four of the 148 have
        # a secondaryIcon nearer 400px and would otherwise swap to it -- and
        # the whole renderer is only the fallback. thumbnail() and
        # accessibility_label() both already search at any depth, so that
        # fallback costs nothing and assumes no key name.
        stations.append(Station(
            station_id=station_id,
            name=(text(renderer.get("name"))
                  or text(renderer.get("callSign"))
                  or text(renderer.get("title"))
                  or accessibility_label(renderer.get("icon") or {})
                  or accessibility_label(renderer)
                  or station_id),
            call_sign=text(renderer.get("callSign")),
            logo=(thumbnail(renderer.get("icon") or {}, prefer_width=400)
                  or thumbnail(renderer, prefer_width=400)),
            airings=airings,
        ))

    if not stations:
        kodiutils.log("no epgRowRenderer in the guide response -- the EPG "
                      "shape may have changed")
    return stations


def merge_airings(stations, more):
    """Fold a later page's airings into the stations already parsed.

    Returns how many were new. A later page repeats nothing, but it is
    deduplicated by video id anyway, because a guide that lists a programme
    twice is worse than one that fetches a page for nothing. Airings that
    belong to no station already known are dropped: without the first page's
    station renderer they have no name and no logo, so they would list as a
    channel called by its own id.
    """
    by_id = {station.station_id: station for station in stations}
    added = 0
    for station in more:
        target = by_id.get(station.station_id)
        if target is None:
            continue
        known = {airing.video_id for airing in target.airings}
        for airing in station.airings:
            if airing.video_id in known:
                continue
            known.add(airing.video_id)
            target.airings.append(airing)
            added += 1
        target.airings.sort(key=lambda a: a.start_ms or 0)
    return added


def continuation_token(response):
    """The token for the next page of guide, if there is one.

    The EPG uses the older ``nextContinuationData`` shape, nested under
    epgPaginationRenderer, rather than the ``continuationCommand`` that most of
    InnerTube has moved to. Both are checked so this keeps working if the guide
    is migrated.
    """
    for block in walk(response, "nextContinuationData"):
        if isinstance(block, dict) and block.get("continuation"):
            return block["continuation"]
    for command in walk(response, "continuationCommand"):
        if isinstance(command, dict) and command.get("token"):
            return command["token"]
    for endpoint in walk(response, "continuationEndpoint"):
        token = first(endpoint, "token")
        if token:
            return token
    return None


class Item(object):
    """Something the UI can show: a folder to browse, or a video to play."""

    __slots__ = ("video_id", "browse_id", "params", "title", "subtitle",
                 "art", "start_ms", "end_ms", "source", "content_type",
                 "duration", "upright", "season", "episode")

    def __init__(self, video_id="", browse_id="", title="", subtitle="",
                 art="", start_ms=0, end_ms=0, params="", source="",
                 content_type="", duration=0, upright=False, season=0,
                 episode=0):
        self.video_id = video_id
        self.browse_id = browse_id
        # What the browse endpoint asks for *within* that page. The Browse
        # tab's five category chips are one browseId, FEunplugged_chips,
        # told apart only by this -- so a reader that drops it turns Sports,
        # Shows, Movies, News and Family into five copies of one folder.
        self.params = params
        self.title = title
        self.subtitle = subtitle
        self.art = art
        self.start_ms = start_ms
        self.end_ms = end_ms
        # The renderer that named it. Kept because not everything with a
        # browse id is a show: a network and a genre chip are both folders,
        # and neither can be recorded.
        self.source = source
        # What YouTube TV says this is: MOVIE, SHOW or EVENT. A tile carries
        # it plainly, which is worth having because nothing else about a
        # tile distinguishes a film -- which has one thing to play and is
        # worth playing on selection -- from a series, which is a folder of
        # episodes. 1048 MOVIE, 303 SHOW and 1 EVENT across the captures.
        self.content_type = content_type
        # Seconds, where the tile says. A film's page gives it as "2:13:57"
        # rather than a number, which Kodi will show as a runtime once it
        # is one.
        self.duration = duration
        # Whether ``art`` is a poster or a wide still, which decides the
        # slot it belongs in and cannot be told from the url.
        self.upright = upright
        # Where an episode sits in its series. Written into one line on the
        # tile -- "S9 E10 * Field of Dreams" -- and Kodi has a field for
        # each of the three, which is what lets a skin sort a season.
        self.season = season
        self.episode = episode

    @property
    def playable(self):
        return bool(self.video_id)


# Where a tile keeps the endpoint you get by selecting it, in the order to
# believe them. Still one level deep, deliberately: a renderer's menu carries
# endpoints for other things entirely ("Go to Rick and Morty", "Add to
# library"), so the first matching endpoint anywhere below would often be the
# wrong one.
#
# "command" is *not* on this list, and that is the point of the list. It is
# the key an unpluggedMenuItemRenderer keeps its watchEndpoint under, so
# accepting it would list the two buttons of a "Join live / Start from
# beginning" dialog as two rows of their own.
#
# entityPageNavigationEndpoint comes last: it is the show page behind a tile
# that also has somewhere better to go. No renderer in any capture carries it
# without a navigationEndpoint, so it only ever answers when nothing else has.
_ENDPOINT_CARRIERS = ("navigationEndpoint", "onSelectCommand", "tapCommand",
                      "entityPageNavigationEndpoint")


def _endpoint_id(node, endpoint, key):
    """The id under a named endpoint, or "" -- see _endpoint_of."""
    block = _endpoint_of(node, endpoint, key)
    return block.get(key, "") if block else ""


def _endpoint_params(node, endpoint, key):
    """The ``params`` of whichever endpoint answered _endpoint_id."""
    block = _endpoint_of(node, endpoint, key)
    found = block.get("params") if block else None
    return found if isinstance(found, str) else ""


def _endpoint_of(node, endpoint, key):
    """The endpoint block naming ``key``, searching only this renderer.

    The web client puts it under navigationEndpoint. The TV client answered
    the Library with nine correctly named tabs holding nothing at all --
    nineteen unpluggedBrowseItemRenderers that parse_items could not place --
    which is what a tile whose endpoint is filed elsewhere looks like.
    """
    for carrier in _ENDPOINT_CARRIERS:
        block = node.get(carrier)
        if not isinstance(block, dict):
            continue
        found = block.get(endpoint)
        if isinstance(found, dict) and found.get(key):
            return found
    block = node.get(endpoint)
    if isinstance(block, dict) and block.get(key):
        return block

    # Nothing under the name this addon knows. Take any endpoint that names
    # the id instead, rather than guess at another name.
    #
    # The TV client's unpluggedBrowseItemRenderer carries a primaryText, a
    # thumbnail and a navigationEndpoint -- everything a tile needs -- and
    # was still dropped, nineteen times over, because what sits inside that
    # endpoint is called neither watchEndpoint nor browseEndpoint. A
    # navigationEndpoint has exactly one destination, so an endpoint under
    # it holding a videoId *is* the video and one holding a browseId *is*
    # the page, whatever Google decided to call it this year.
    #
    # Only one level down, so this cannot reach into an
    # unpluggedPopupEndpoint's dialog (still read by _popup_video_id, which
    # picks the right one of its two buttons) or a menu. And it stays silent
    # on the endpoints that name no id at all, so the ten Rick and Morty buy
    # prompts, whose unpluggedInitiateInlinePurchaseCommand carries only
    # params, are still correctly dropped.
    for carrier in _ENDPOINT_CARRIERS:
        block = node.get(carrier)
        if not isinstance(block, dict):
            continue
        for name, value in block.items():
            if (name.endswith("Endpoint") and isinstance(value, dict)
                    and value.get(key)):
                return value
    return None


def _varint(data, at):
    shift = value = 0
    while at < len(data):
        byte = data[at]
        at += 1
        value |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return value, at
        shift += 7
        if shift > 63:
            break
    return None, at


def _protobuf_strings(data, depth=0):
    """Every length-delimited field in a protobuf, and those nested inside.

    A deliberately small reader: enough to walk a token whose schema is not
    published, and no more. Anything it cannot make sense of ends the walk
    rather than guessing, because a wrong offset in a protobuf produces
    plausible nonsense rather than an error.
    """
    at = 0
    while at < len(data):
        tag, at = _varint(data, at)
        if tag is None:
            return
        wire = tag & 7
        if wire == 0:
            value, at = _varint(data, at)
            if value is None:
                return
        elif wire == 1:
            at += 8
        elif wire == 5:
            at += 4
        elif wire == 2:
            length, at = _varint(data, at)
            if length is None or at + length > len(data):
                return
            chunk = data[at:at + length]
            at += length
            yield chunk
            if depth < 4:
                for inner in _protobuf_strings(chunk, depth + 1):
                    yield inner
        else:
            return          # a group; not something these tokens use


# What a browse id looks like: "UCmXMw6OyWJH1O6cA7JZS9Fg" for a show or a
# team, "SEEV_g_11z7gny2t0" for an event. Long enough, and made only of the
# characters an id is made of, which is what separates it from the protobuf
# framing around it.
_BROWSE_ID = re.compile(r"^[A-Za-z0-9_-]{8,64}$")


# A video id is eleven characters; a channel or show id is twenty-four
# beginning "UC". A side-sheet command for a programme carries both -- the
# show it belongs to and the programme itself -- so which one is wanted
# depends on the caller, and neither is guessed at by position.
_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")


def _sidesheet_ids(params):
    """Every id-shaped string inside a side-sheet command's params."""
    if not isinstance(params, str) or not params:
        return
    token = unquote(params)
    try:
        raw = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4))
    except (binascii.Error, ValueError):
        return
    for chunk in _protobuf_strings(raw):
        try:
            found = chunk.decode("ascii")
        except UnicodeDecodeError:
            continue
        if _BROWSE_ID.match(found):
            yield found


def sidesheet_video_id(params):
    """The programme's own video id inside a side-sheet command.

    A guide airing that is not the one currently on the air carries no
    watchEndpoint and no videoId field: its navigationEndpoint holds an
    unpluggedGetSidesheetCommand, exactly as the Library's tiles do. Of the
    989 airings in the 2026-08-29 20:48 guide, 143 had a watchEndpoint --
    one per station, the one on the air -- and the other 846 had a side
    sheet. Every one of those 846 carries exactly two ids: the show's
    twenty-four character one and the programme's eleven-character one.

    Reading only the endpoint is why the guide listed one programme per
    channel and nothing after it.
    """
    for found in _sidesheet_ids(params):
        if _VIDEO_ID.match(found):
            return found
    return ""


def sidesheet_id(params):
    """The browse id buried in an unpluggedGetSidesheetCommand's params.

    The TV client's Library tiles do not navigate: each carries a
    navigationEndpoint holding unpluggedGetSidesheetCommand, which opens a
    detail panel. There is no browseId field anywhere on the tile, so all
    nineteen were dropped as naming nowhere to go.

    The id is inside the command's params, base64 of a small protobuf. In
    the 2026-08-29 capture every one of the nineteen decoded to a nested
    field holding the same id the web client puts in a plain browseEndpoint
    -- UCmXMw6OyWJH1O6cA7JZS9Fg for Pittsburgh Steelers, and so on for all
    seven distinct titles -- which is what makes reading it a measurement
    rather than a hope.

    The outer field number varies by what the tile is (3 for a movie, 4 for
    a show, 7 for a sports team), so the walk is by shape rather than by
    field number: the first nested string that looks like an id.
    """
    for found in _sidesheet_ids(params):
        return found
    return ""


def _sidesheet_browse_id(node):
    """The id a tile hides in a side-sheet command, if it has one."""
    for carrier in _ENDPOINT_CARRIERS:
        block = node.get(carrier)
        if not isinstance(block, dict):
            continue
        command = block.get("unpluggedGetSidesheetCommand")
        if isinstance(command, dict):
            found = sidesheet_id(command.get("params"))
            if found:
                return found
    return ""


def _popup_video_id(node):
    """The video a tile hides behind a "how would you like to watch?" dialog.

    A scheduled recording that is on the air right now carries no
    watchEndpoint at all: its navigationEndpoint is an
    unpluggedPopupEndpoint whose dialog offers "Join live" and "Start from
    beginning". Both name the same videoId, so either will do, and the
    params that separate them are not something route_play carries anyway.

    Every recording that has not started yet carries a plain browseEndpoint
    instead -- measured across the seven tiles in the Library capture, where
    only the one then on the air had the popup. So the popup's presence is
    YouTube TV's own statement that this one is playable now, and no clock
    arithmetic is needed here. Without this the live tile was dropped
    entirely: it has a title and a thumbnail and, as far as _endpoint_id
    could see, nowhere to go.
    """
    for carrier in _ENDPOINT_CARRIERS:
        block = node.get(carrier)
        if not isinstance(block, dict):
            continue
        popup = block.get("unpluggedPopupEndpoint")
        if not isinstance(popup, dict):
            continue
        for endpoint in walk(popup, "watchEndpoint"):
            if isinstance(endpoint, dict) and endpoint.get("videoId"):
                return endpoint["videoId"]
    return ""


def _title_of(node):
    for field in ("primaryText", "title", "headline", "label"):
        value = text(node.get(field))
        if value:
            return value
    return ""


def _subtitle_of(node):
    parts = []
    for field in ("secondaryText", "tertiaryText", "descriptionSnippet"):
        value = text(node.get(field))
        if value and value not in parts:
            parts.append(value)
    return " • ".join(parts)


def _seconds_ms(node, field):
    try:
        return int(node[field]) * 1000
    except (KeyError, TypeError, ValueError):
        return 0


def _selector_labels(selectors):
    """The names a page gives its own deferred shelves, in order.

    The web client wraps each in a dropdownItemRenderer; the TV client does
    not, and asking for that name by itself logged ten shelves called
    "shelf". Take any renderer under the selector block that carries a label
    or a title, which is what a selector is, rather than one renderer name.
    """
    labels = []
    def visit(node):
        if isinstance(node, dict):
            for name, value in node.items():
                if (name.endswith("Renderer") and isinstance(value, dict)):
                    label = text(value.get("label")) or text(value.get("title"))
                    if label:
                        labels.append(label)
                        continue
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)
    visit(selectors)
    return labels


def section_continuations(response):
    """(label, token) for every deferred shelf behind a page's own selector.

    A show page does not carry its episodes. Browsing Rick and Morty answers
    with the two newest episodes inline and nothing else: the ten seasons
    ("Season 1".."Season 9", "Extras") are ten empty shelves under an
    unpluggedSelectableSectionRenderer, each holding only a continuation
    token. The addon asked for the page and listed what was in it, which is
    why the cookie path showed two episodes where the account is entitled to
    nine -- the other seven were one request away and never requested.

    The selector labels and the shelves are two parallel lists rather than one
    structure, so they are paired by position: selectors[i] names contents[i].
    Labels are returned so a caller can say which shelf a request is for; the
    order is the page's own.
    """
    pairs = []
    for section in walk(response, "unpluggedSelectableSectionRenderer"):
        if not isinstance(section, dict):
            continue
        labels = _selector_labels(section.get("selectors"))
        for index, contents in enumerate(section.get("contents") or []):
            token = first(contents, "continuation")
            if not isinstance(token, str) or not token:
                continue
            pairs.append((labels[index] if index < len(labels) else "", token))
    return pairs


def parse_items(response):
    """Every renderer that names something to play or browse.

    Matched by shape rather than by renderer name. The first version of this
    listed the renderer names it expected -- tileRenderer, videoRenderer and
    friends -- and returned nothing at all, because YouTube TV uses its own
    (unpluggedGridVideoRenderer, unpluggedBrowseItemRenderer,
    unpluggedCompactVideoVersionRenderer). Names change; carrying a
    watchEndpoint and a title does not.
    """
    items = []
    seen = set()

    def visit(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if key.endswith("Renderer") and isinstance(value, dict):
                    _collect(value, key)
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    def _collect(renderer, source=""):
        title = _title_of(renderer)
        if not title:
            return
        # A plain videoId/browseId field beside the endpoints counts too:
        # that is where the guide keeps the id of every programme that is
        # not the one currently on the air.
        video_id = (_endpoint_id(renderer, "watchEndpoint", "videoId")
                    or _popup_video_id(renderer)
                    or (renderer.get("videoId")
                        if isinstance(renderer.get("videoId"), str) else ""))
        browse_id = "" if video_id else (
            _endpoint_id(renderer, "browseEndpoint", "browseId")
            or (renderer.get("browseId")
                if isinstance(renderer.get("browseId"), str) else "")
            or _sidesheet_browse_id(renderer))
        if not video_id and not browse_id:
            return
        params = ("" if video_id
                  else _endpoint_params(renderer, "browseEndpoint", "browseId"))
        # Keyed by destination *and* start time. Destination alone collapsed
        # two Phineas and Ferb recordings an hour apart into one row, because
        # both point at the same show page; two airings are two rows. Nothing
        # without a start time is affected, which is every show page.
        #
        # The params are part of the destination for the same reason: the
        # Browse tab's five category chips share one browseId and differ
        # only there, and keying without them left one chip of five.
        season, number, named = episode_of(renderer)
        if named:
            # "S9 E10 * Field of Dreams" is three fields in one string, and
            # Kodi draws its own "9x10" from the numbers. Leaving the whole
            # line as the title prints the numbers twice.
            title = named
        key = (video_id or browse_id, params,
               _seconds_ms(renderer, "startTimeSeconds"))
        if key in seen:
            return
        seen.add(key)
        items.append(Item(
            video_id=video_id,
            browse_id=browse_id,
            params=params,
            title=title,
            subtitle=_subtitle_of(renderer),
            art=thumbnail(renderer.get("thumbnail") or {}, prefer_width=1280),
            start_ms=_seconds_ms(renderer, "startTimeSeconds"),
            end_ms=_seconds_ms(renderer, "endTimeSeconds"),
            source=source,
            content_type=_content_type(renderer),
            duration=_duration(renderer),
            upright=is_portrait(renderer.get("thumbnail") or {}),
            season=season,
            episode=number,
        ))

    visit(response)
    return items


def unplayable_count(response):
    """How many things a response names that cannot be opened.

    parse_items drops a renderer with a title and no endpoint, which is what
    an episode the account has no rights to looks like: YouTube TV lists it,
    greyed, with no watchEndpoint. That is the correct thing to drop and the
    wrong thing to drop silently -- a shelf holding ten unplayable episodes
    and a shelf holding nothing both logged "0 of 0", and only one of those
    is a show you cannot watch.

    Counted the same way parse_items decides, so the two always agree.
    """
    count = 0
    seen = set()

    def visit(node):
        nonlocal count
        if isinstance(node, dict):
            for key, value in node.items():
                if key.endswith("Renderer") and isinstance(value, dict):
                    title = _title_of(value)
                    # A thumbnail is what separates a tile from a badge or a
                    # menu entry, which also carry a title and no endpoint.
                    if (title and value.get("thumbnail")
                            and not _endpoint_id(value, "watchEndpoint",
                                                 "videoId")
                            and not _endpoint_id(value, "browseEndpoint",
                                                 "browseId")
                            and not _popup_video_id(value)
                            and not value.get("videoId")
                            and not value.get("browseId")
                            and not _sidesheet_browse_id(value)
                            and title not in seen):
                        seen.add(title)
                        count += 1
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    visit(response)
    return count


def unreadable_sample(node, limit=3):
    """Key names of renderers that look like tiles but name nowhere to go.

    parse_items drops a renderer carrying a title and no endpoint it knows.
    That is right for an episode the account has no rights to and wrong for a
    tile whose endpoint is simply filed under a key this addon has not seen,
    and the two are indistinguishable in a count: the TV client's Library
    came back as nine correctly named tabs holding nothing, which is what
    nineteen perfectly good tiles look like when their endpoint is somewhere
    unexpected.

    Listing the keys such a renderer actually carries names the one to read
    next, and costs a log line rather than another round trip.
    """
    out = []

    def visit(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if (len(out) < limit and key.endswith("Renderer")
                        and isinstance(value, dict) and _title_of(value)
                        and value.get("thumbnail")
                        and not _endpoint_id(value, "watchEndpoint", "videoId")
                        and not _endpoint_id(value, "browseEndpoint", "browseId")
                        and not _popup_video_id(value)):
                    inside = []
                    for carrier in _ENDPOINT_CARRIERS:
                        block = value.get(carrier)
                        if isinstance(block, dict):
                            inside.append("%s -> [%s]"
                                          % (carrier,
                                             ", ".join(sorted(block.keys()))))
                    out.append("%s carries [%s]%s"
                               % (key, ", ".join(sorted(value.keys())),
                                  "; " + "; ".join(inside) if inside else ""))
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    visit(node)
    return out


def renderer_sample(response, limit=8):
    """The keys one example of each renderer name carries.

    unreadable_sample asks for a title and a thumbnail before it reports a
    renderer, so a client that files *those* elsewhere too gets reported as
    nothing at all -- which is what happened: a page holding nineteen tiles
    produced no sample line. This asks for nothing. It cannot come back
    empty while the response holds any renderer, which is the property a
    last-resort diagnostic needs.

    Ordered by how many of each there are, so the tile renderer -- the
    numerous one -- leads.
    """
    counts = {}
    first_seen = {}

    def visit(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if key.endswith("Renderer") and isinstance(value, dict):
                    counts[key] = counts.get(key, 0) + 1
                    if key not in first_seen:
                        first_seen[key] = sorted(value.keys())
                visit(value)
        elif isinstance(node, list):
            for value in node:
                visit(value)

    visit(response)
    ranked = sorted(counts.items(), key=lambda pair: -pair[1])[:limit]
    return ["%s x%d carries [%s]" % (name, count,
                                     ", ".join(first_seen[name]))
            for name, count in ranked]


def parse_search(response):
    """Search hits.

    YouTube TV answers a search with shows and scheduled airings, which carry a
    browseEndpoint rather than a watchEndpoint -- you browse into them to reach
    an episode. So most results are folders, and any that happen to be directly
    playable come back playable.
    """
    return parse_items(response)


class Section(object):
    """A named row of a page: what it holds, and how to ask for more."""

    __slots__ = ("title", "items", "token", "browse_id", "params")

    def __init__(self, title, items, token="", browse_id="", params=""):
        self.title = title
        self.items = items
        self.token = token
        # A row asks for more with a token. A *tab* need not: the TV client
        # may hand one a page of its own to go and fetch instead, so a
        # section can name a destination as well as a continuation.
        self.browse_id = browse_id
        self.params = params


def _section_list(response):
    """The page's own top-level list of rows.

    A first request answers with sectionListRenderer; the Library arrives as
    a continuation, so it answers with sectionListContinuation. Only the
    direct entries are wanted -- searching the whole tree for shelfRenderer
    would also find the nineteen cells inside the filter grid below, which
    are shelves too and are not rows of this page.
    """
    for key in ("sectionListContinuation", "sectionListRenderer",
                "unpluggedLibraryContinuation"):
        block = first(response, key)
        if not isinstance(block, dict):
            continue
        if isinstance(block.get("contents"), list):
            return block["contents"]
        # unpluggedLibraryContinuation, which the TV client answers the
        # Library with, holds one renderer under "content" rather than a
        # list of rows: the whole page is a single selectable section.
        if isinstance(block.get("content"), dict):
            return [block["content"]]
    return []


def _dropdown(block):
    """(label, is_selected) for each entry of a dropdownRenderer."""
    entries = []
    for entry in (block.get("entries") or []):
        if not isinstance(entry, dict):
            continue
        item = entry.get("dropdownItemRenderer")
        if isinstance(item, dict):
            entries.append((text(item.get("label")), bool(item.get("isSelected"))))
    return entries


def _chip_labels(selectors):
    """The names on a chip row.

    The TV client puts the Library's tabs in an
    unpluggedHorizontalChipListRenderer rather than the web client's filter
    and sort dropdowns. Read explicitly rather than through
    _selector_labels, which stops at the first renderer carrying a title:
    if the chip list itself ever gains one, that would return a single
    label for nine tabs and the pairing below would rightly refuse to run.
    """
    labels = []
    for chip in walk(selectors, "unpluggedChipRenderer"):
        if isinstance(chip, dict):
            labels.append(text(chip.get("title")) or text(chip.get("label")))
    return labels


def _filter_cells(section):
    """(label, cell) for each tab of a selectable section, or None.

    Two selectors, two pairings, and getting them the wrong way round names
    a tab with somebody else's row -- so each is checked against the number
    of cells before it is used, and a mismatch returns None rather than a
    best effort.

    The web client sends an unpluggedFilterSortSelectorRenderer: a filter
    dropdown and one sort dropdown per filter, with ``contents`` holding the
    cross product flattened row by row. Six filters, 4+6+1+4+1+3 sorts,
    nineteen cells. Each filter is represented by its selected sort.

    The TV client sends an unpluggedHorizontalChipListRenderer instead --
    nine chips, nine cells, one each -- so there is no cross product to
    unpick and the pairing is positional.
    """
    contents = section.get("contents") or []
    selector = first(section, "unpluggedFilterSortSelectorRenderer")
    if isinstance(selector, dict):
        filters = _dropdown((selector.get("filterSelector") or {})
                            .get("dropdownRenderer") or {})
        sorts = [_dropdown(entry.get("dropdownRenderer") or {})
                 for entry in (selector.get("sortSelectors") or [])
                 if isinstance(entry, dict)]
        total = sum(len(row) for row in sorts)
        if len(sorts) != len(filters) or total != len(contents):
            kodiutils.log("library: %d filter(s), %d sort list(s) totalling "
                          "%d, but %d cell(s) -- the grid has changed shape"
                          % (len(filters), len(sorts), total, len(contents)))
            return None
        pairs = []
        at = 0
        for index, (name, _selected) in enumerate(filters):
            row = sorts[index]
            chosen = next((i for i, (_l, s) in enumerate(row) if s), 0)
            pairs.append((name, contents[at + chosen]))
            at += len(row)
        return pairs

    labels = _chip_labels(section.get("selectors"))
    if not labels:
        labels = _selector_labels(section.get("selectors"))
    if not labels or len(labels) != len(contents):
        kodiutils.log("library: %d tab name(s) but %d cell(s) -- the "
                      "selector has changed shape" % (len(labels), len(contents)))
        return None
    return list(zip(labels, contents))


def library_filters(response):
    """The Library's filter tabs, each with the row behind it.

    The Library is not a page of shelves like a show page. One
    unpluggedSelectableSectionRenderer carries the tabs and one cell of
    ``contents`` per tab, and the two clients spell the tabs differently --
    dropdowns on the web, a chip row on the TV. _filter_cells pairs them,
    and refuses rather than mispair.

    A tab with nothing in it comes back as an unpluggedEmptyStateRenderer
    ("No movies in your library") -- no items and no token -- and is dropped,
    so an empty tab never becomes an empty folder. A tab YouTube TV has not
    selected arrives with only a continuation token, which the caller
    follows.
    """
    sections = []
    for block in walk(response, "unpluggedSelectableSectionRenderer"):
        if not isinstance(block, dict):
            continue
        pairs = _filter_cells(block)
        if not pairs:
            continue
        for name, cell in pairs:
            items = parse_items(cell)
            token = first(cell, "continuation") or ""
            if not items and not token:
                continue
            sections.append(Section(name or "Library", items,
                                    token if isinstance(token, str) else ""))
    return sections


# The renderers a page uses for a named row, and where each keeps its name.
# The Library calls them shelfRenderer with a "title"; Home calls them
# unpluggedHomeShelfRenderer with a "primaryText". Same thing, twice named.
_SHELVES = (("shelfRenderer", "title"),
            ("unpluggedHomeShelfRenderer", "primaryText"))


def page_shelves(response):
    """The named rows of a page, in the page's own order.

    The Library's "New in your library", "Most watched" and "Scheduled
    recordings"; Home's "Resume watching", "Top picks for you", "Sports" and
    the twenty genre rows behind them.

    A row with a name and nothing in it is dropped -- Home answers with
    "Add to your library" and "Upcoming games" holding no items at all, and
    an empty folder is worse than no folder.
    """
    sections = []
    for entry in _section_list(response):
        if not isinstance(entry, dict):
            continue
        for name, title_key in _SHELVES:
            shelf = entry.get(name)
            if not isinstance(shelf, dict):
                continue
            title = text(shelf.get(title_key))
            items = parse_items(shelf)
            if not title or not items:
                continue
            token = first(shelf, "continuation") or ""
            sections.append(Section(title, items,
                                    token if isinstance(token, str) else ""))
            break
    return sections


def page_continuation(response):
    """The token for the page's *next* page, and nothing else.

    Deliberately not continuation_token, which searches the whole tree: the
    first nextContinuationData in a Home response belongs to the first
    shelf, not to the page, and following it would fetch more of "Top picks
    for you" while believing it had fetched the next twenty rows. The page's
    own token sits in the section list's ``continuations``, alongside a
    timedContinuationData (a refresh timer) and a reloadContinuationData
    (the page again), neither of which is a next page.
    """
    for key in ("sectionListContinuation", "sectionListRenderer"):
        block = first(response, key)
        if not isinstance(block, dict):
            continue
        for entry in (block.get("continuations") or []):
            if not isinstance(entry, dict):
                continue
            data = entry.get("nextContinuationData")
            if isinstance(data, dict) and data.get("continuation"):
                return data["continuation"]
    return None


def parse_library(response):
    """(shelves, filters) for the Library page.

    Kept apart because they are read differently and shown differently: the
    shelves are curated rows, the filters are one collection sliced six ways.
    """
    return page_shelves(response), library_filters(response)


_TITLE_KEYS = ("title", "primaryText", "headerText", "shelfTitle")


def any_rows(response, least=2):
    """Named rows found by shape, for a page whose container is unknown.

    page_shelves knows two containers, both read off web-client captures.
    The TV client answers the Library with something else -- 0 rows, 0
    filters, and a flat listing of whatever parse_items could reach -- so
    this is the reader that does not need to know the container's name.

    A row is any renderer that carries a title and has at least ``least``
    playable-or-browsable things under it. Only the innermost such renderer
    is kept: a page is itself a titled renderer containing every row, and
    returning that alongside its own children would list everything twice.
    Containment is tracked with an ancestor stack rather than inferred from
    the item sets, which would be a guess whenever two rows happen to
    overlap.
    """
    found = []

    def visit(node, ancestors):
        if isinstance(node, dict):
            for key, value in node.items():
                if not (key.endswith("Renderer") and isinstance(value, dict)):
                    visit(value, ancestors)
                    continue
                title = ""
                for name in _TITLE_KEYS:
                    title = text(value.get(name))
                    if title:
                        break
                if not title:
                    visit(value, ancestors)
                    continue
                items = parse_items(value)
                if len(items) < least:
                    visit(value, ancestors)
                    continue
                mine = len(found)
                found.append([title, items, first(value, "continuation") or "",
                              set(ancestors), False])
                for index in ancestors:
                    found[index][4] = True      # an ancestor has a child row
                visit(value, ancestors + [mine])
        elif isinstance(node, list):
            for value in node:
                visit(value, ancestors)

    visit(response, [])
    rows = []
    for title, items, token, _ancestors, has_child in found:
        if has_child:
            continue
        rows.append(Section(title, items, token if isinstance(token, str) else ""))
    return rows


_MESSAGE_KEYS = ("responseText", "notificationText", "messageText",
                 "alertText", "title", "text")


def action_text(response, default=""):
    """What a mutation's ``actions`` block asks the client to say.

    Both DVR endpoints answer with ``actions`` and ``responseContext`` and
    nothing else -- seen 2026-08-29, for a start and a stop of the same show
    -- so a message inside that block is the only part of the response that
    reports what happened. YouTube TV puts its toast there ("Added to your
    library"), and a refusal reads the same way to ``call``: a 200 with a
    different sentence in it.

    Which renderer holds it is not established, so the message is searched
    for by the key names such text arrives under, most specific first.
    ``text`` comes last because every run in the tree is stored under that
    name and it would otherwise win over the toast's own field.
    """
    for actions in walk(response, "actions"):
        for key in _MESSAGE_KEYS:
            for node in walk(actions, key):
                said = (node if isinstance(node, str) else text(node)).strip()
                if said:
                    return said
    return default


def _clock(written):
    """"24:03" and "2:13:57" as seconds, and anything else as nothing."""
    total = 0
    for part in written.split(":"):
        try:
            total = total * 60 + int(part)
        except ValueError:
            return 0
    return total


def _counter_badge(renderer):
    """An episode's runtime, which it keeps in a badge rather than a field.

    A film's tile says ``lengthSeconds``. An episode says nothing of the
    kind: Rick and Morty's S9 E10 carries its 24:03 in an
    unpluggedTextBadgeRenderer of ``type: "COUNTER"``, beside a VOD badge
    of type VIDEO_VERSION that is not a runtime and must not be read as
    one. So the type is checked, not just the shape of the text.
    """
    for badge in walk(renderer, "unpluggedTextBadgeRenderer"):
        if not isinstance(badge, dict) or badge.get("type") != "COUNTER":
            continue
        seconds = _clock(text(badge.get("label")))
        if seconds:
            return seconds
    return 0


def _duration(renderer):
    """A tile's runtime in seconds, from a number, "2:13:57", or a badge."""
    seconds = renderer.get("lengthSeconds")
    try:
        if seconds:
            return int(seconds)
    except (TypeError, ValueError):
        pass
    written = text(renderer.get("duration"))
    return _clock(written) if written else _counter_badge(renderer)


_EPISODE = re.compile(r"^S(\d+)\s*E(\d+)\b\s*(?:[\u2022|-]\s*)?(.*)$")


def episode_of(renderer):
    """(season, episode, name) for an episode tile, or (0, 0, "").

    An episode's primaryText is the whole thing in one line: Rick and
    Morty's is "S9 E10 \u2022 Field of Dreams". Kodi has a field for each
    of the three, and given them a skin sorts and labels a series properly
    instead of showing one long string.
    """
    found = _EPISODE.match(text(renderer.get("primaryText")).strip())
    if not found:
        return 0, 0, ""
    return int(found.group(1)), int(found.group(2)), found.group(3).strip()


HEADER = "unpluggedContentDetailsHeaderRenderer"


_SUGGESTION_KINDS = {"movie": "MOVIE", "show": "SHOW", "team": "SPORTS_TEAM",
                     "event": "EVENT", "network": "NETWORK"}


def suggestion_kinds(response):
    """{browse id: kind} from a suggest response, and the answer is in words.

    Search types a film SHOW and its tiles carry no menu, so nothing in a
    search result says what a thing is. **suggest does**, plainly, next to
    the same browse id: "The Blues Brothers / Movie", "Air Disasters /
    Show", "St. Louis Blues / Team". One 20 KB call for a query, against a
    page fetch for every result that needs typing.

    Read out of the suggestion's secondaryContainer, from the text renderer
    rather than the badge beside it -- that badge is "$", which says a title
    must be bought, not what it is.
    """
    found = {}
    for entry in walk(response, "entitySuggestionRenderer"):
        if not isinstance(entry, dict):
            continue
        endpoint = first(entry, "browseEndpoint")
        browse_id = (endpoint or {}).get("browseId")
        if not isinstance(browse_id, str) or not browse_id:
            continue
        for holder in walk(entry.get("secondaryContainer") or {},
                           "unpluggedTextRenderer"):
            said = text((holder or {}).get("text")).strip().lower()
            kind = _SUGGESTION_KINDS.get(said)
            if kind:
                found[browse_id] = kind
                break
    return found


def browse_rows(response, least=20):
    """(categories, networks) off the Browse tab.

    The tab holds one enormous row of networks -- 256 of them -- and one
    small row of category chips. Told apart by size rather than by name,
    because the names are YouTube TV's ("Browse" for the chips, "Networks"
    for the networks) and a renamed row should not lose the networks.

    The *biggest* row rather than the first one over ``least``: with a
    threshold alone, two rows that both clear it hand back whichever came
    first, and the categories would be listed as the networks.
    """
    rows = page_shelves(response) or any_rows(response)
    networks = max(rows, key=lambda row: len(row.items), default=None)
    if networks is not None and len(networks.items) < least:
        networks = None
    categories = [item for row in rows if row is not networks
                  for item in row.items if item.browse_id]
    return categories, networks


def title_header(response):
    """The header of a page about one title, or None.

    A film or show page carries an unpluggedContentDetailsHeaderRenderer; a
    network page carries an unpluggedNetworkPromoHeaderRenderer. That is the
    difference between a page whose tabs are a menu -- Live, Series, Movies,
    each a different part of a channel -- and a page whose tabs are one
    thing and some notes about it, where the tab menu is in the way.
    """
    found = first(response, HEADER)
    return found if isinstance(found, dict) else None


def page_description(response):
    """A title's synopsis, which its About tab holds and nothing else does."""
    for block in walk(response, "unpluggedContentDetailsAboutFieldsRenderer"):
        said = text(block.get("description") if isinstance(block, dict) else None)
        if said:
            return said
    return ""


def _from_one_string(whole):
    """One About line that arrived as a single string, as (label, value).

    ``Provider: Lionsgate``, ``Directors: Chad Stahelski``, ``Released
    2016``, ``On FX`` -- and ``Action, Thriller``, which is the genres and
    carries no label at all.

    The label is only claimed when it is one this knows, so a genres line
    is never mistaken for one: a colon is not enough on its own.
    """
    whole = whole.strip()
    label, sep, value = whole.partition(":")
    if sep and label.strip().lower() in _ABOUT_FIELDS:
        return label.strip(), value.strip()
    for word in ("Released", "On"):
        if whole.startswith(word + " "):
            return word, whole[len(word) + 1:].strip()
    return "", whole


def _attribute(node):
    """One About line as (label, value).

    Three shapes. A labelled line marks its label bold -- ``Provider: ``
    then ``Disney``, ``Directors`` then ``: `` then ``Gareth Edwards``; an
    unlabelled one reads ``Released 2016`` or ``On FX``; and the genres
    line has no label at all, being simply "Science fiction, Adventure,
    Action, Fantasy".

    The third shape is a whole line in one ``simpleText``, and it is what
    this client actually sends. Only the browser's runs were ever looked
    at, so every simpleText attribute came back unlabelled -- which is how
    the genres line is recognised -- and each one in turn overwrote the
    genres with itself. John Wick: Chapter 4's About tab named all three
    paths on this client at 2026-08-30 02:04:
    ``.../attributes/simpleText`` beside ``.../attributes/runs/text``.
    """
    if not isinstance(node, dict):
        return "", ""
    said = node.get("simpleText")
    if isinstance(said, str):
        return _from_one_string(said)
    runs = node.get("runs")
    if not isinstance(runs, list):
        return "", ""
    bold = "".join(run.get("text", "") for run in runs
                   if isinstance(run, dict) and run.get("bold"))
    plain = "".join(run.get("text", "") for run in runs
                    if isinstance(run, dict) and not run.get("bold"))
    if bold:
        return bold.strip().strip(":").strip(), plain.strip()
    return _from_one_string("".join(run.get("text", "") for run in runs
                                    if isinstance(run, dict)))


_ABOUT_FIELDS = {"released": "year", "provider": "studio", "on": "network",
                 "directors": "directors", "director": "directors",
                 "writers": "writers", "writer": "writers",
                 "producers": "producers", "producer": "producers",
                 # Named by the diagnostic rather than guessed at: "about
                 # says something new -- Production Companies: Escape
                 # Artists, Zhiv, Mace Neufeld Productions".
                 "production companies": "companies",
                 "production company": "companies"}


def about_fields(response):
    """Everything a title's About tab says about it.

    A film's page carries far more than the year and rating its tile does:
    "Science fiction, Adventure, Action, Fantasy", "Released 2016", "On FX",
    "Provider: Disney", "Directors: Gareth Edwards", and a real synopsis.

    Labels this does not know are returned under ``unknown`` rather than
    dropped, so a title carrying one names it in a log instead of it going
    quietly missing.
    """
    found = {"genres": [], "unknown": [], "lines": []}
    for block in walk(response, "unpluggedContentDetailsAboutFieldsRenderer"):
        if not isinstance(block, dict):
            continue
        said = text(block.get("description"))
        if said:
            found["description"] = said
        for entry in (block.get("attributes") or []):
            label, value = _attribute(entry)
            if not value:
                continue
            # Kept verbatim as well as parsed. A show carries less than a
            # film and it is not established what: Saturday Night Live came
            # back with a synopsis and nothing else, and only the lines it
            # actually sent can say whether they were unread or unsent.
            found["lines"].append("%s=%s" % (label or "-", value))
            span = _RUN_SPAN.match(value)
            if not label and span:
                # A show's years, which it gives instead of a release date:
                # "2013 - Present", "1994 - 2004". Named by the diagnostic
                # -- 45 of them in one run, every one reported unlabelled
                # -- and it is a year and a status, not a genre.
                found.setdefault("year", int(span.group(1)))
                found["status"] = ("Continuing"
                                   if span.group(2).lower() == "present"
                                   else "Ended")
                found["ended"] = (0 if span.group(2).lower() == "present"
                                  else int(span.group(2)))
                continue
            if not label:
                # The unlabelled line is the genres, comma separated -- and
                # the *first* one is. A line this cannot label is not
                # thereby the genres, and letting each in turn overwrite
                # the last is how "Animated, Action, Adventure, Comedy"
                # became whatever came after it.
                if not found["genres"]:
                    found["genres"] = [part.strip()
                                       for part in value.split(",")
                                       if part.strip()]
                else:
                    found["unknown"].append("unlabelled: %s" % value)
                continue
            field = _ABOUT_FIELDS.get(label.lower())
            if field == "year":
                try:
                    found["year"] = int(value[:4])
                except ValueError:
                    pass
            elif field in ("directors", "writers", "producers",
                           "companies"):
                found[field] = [part.strip() for part in value.split(",")
                                if part.strip()]
            elif field in ("studio", "network"):
                # Several, comma separated: "Adult Swim, Cartoon Network,
                # HBO Max" is three studios and not one long name.
                found[field] = [part.strip() for part in value.split(",")
                                if part.strip()]
            elif field:
                found[field] = value
            else:
                found["unknown"].append("%s: %s" % (label, value))
    return found


def episode_facts(response):
    """(rating, runtime) that a show keeps on its episodes, not its header.

    A film's header says "PG-13 \u2022 2016". **A show's says neither.**
    Rick and Morty's is "2013 \u2013 Present" and there is no rating
    anywhere above it -- which is why a show reached Kodi unrated while a
    film did not.

    Its episodes have both. Each one's secondaryText reads "Adult Swim
    \u2022 TV-14 \u2022 13d ago" and each carries a COUNTER badge holding
    "24:03", so the rating a show is carrying is the one its episodes
    agree on, and a typical episode's runtime is the show's.

    The first of each is taken rather than a vote: they agree across a
    series, and one that did not would be a per-episode fact and not the
    show's anyway.
    """
    rating, runtime = "", 0
    for renderer in walk(response, "unpluggedCompactVideoRenderer"):
        if not isinstance(renderer, dict):
            continue
        if not rating:
            said, _year = rating_and_year(renderer.get("secondaryText"))
            rating = said
        if not runtime:
            runtime = _counter_badge(renderer)
        if rating and runtime:
            break
    return rating, runtime


def cast_of(response):
    """(name, role, photo) for a title's lead cast, in the page's order.

    The photo is on the person renderer beside the name, protocol-relative
    like every other image here. Without it Kodi draws the silhouette it
    uses for an actor it has no picture of.
    """
    people = []
    for person in walk(response, "unpluggedPersonRenderer"):
        if not isinstance(person, dict):
            continue
        name = text(person.get("name"))
        if name:
            people.append((name, text(person.get("role")),
                           thumbnail(person.get("thumbnail") or {},
                                     prefer_width=288)))
    return people


def title_art(header):
    """A title page's own banner, which its tiles do not carry."""
    if not isinstance(header, dict):
        return ""
    return thumbnail(header.get("banner") or {}, prefer_width=1920)


# "2013 - Present", "1994 - 2004" -- the years a show ran, written with an
# en dash. A film gives "Released 2016" instead and never one of these.
_RUN_SPAN = re.compile(r"^(\d{4})\s*[\u2013\u2014-]\s*(\d{4}|Present)$",
                       re.IGNORECASE)


_RATING = re.compile(r"^(?:TV-[A-Z0-9]{1,3}|G|PG|PG-13|R|NC-17|NR|UR|X)$")


def rating_and_year(node, default=""):
    """("PG-13", 2016) out of a header's "PG-13 \u2022 2016".

    Told apart by shape, and each half only claimed by something that
    looks like it. Four digits is the year. A rating is one of the handful
    of things a rating can be -- and anything else is neither: Saturday
    Night Live's header reads "NBC", which was being shown as "Rated: NBC"
    for want of asking what a rating looks like.
    """
    rating, year = default, 0
    for part in text(node).replace("\u2022", "|").split("|"):
        part = part.strip()
        if not part:
            continue
        if len(part) == 4 and part.isdigit():
            year = int(part)
        elif _RATING.match(part.upper()) and rating == default:
            rating = part
        elif not year:
            # A show gives a span rather than a year -- "2013 - Present",
            # "1975 - Present" -- and the year it started is a year.
            started = re.match(r"^(\d{4})\b", part)
            if started:
                year = int(started.group(1))
    return rating, year


def dvr_state(response):
    """True if this title is in the library, False if not, None if unsaid.

    A tile cannot say -- isToggled is on none of them -- but a title's own
    page can: its header's dvrButtonRenderer carries dvrOn outright. So on
    a page, and only on a page, the one action that applies can be offered
    instead of both.
    """
    for button in walk(response, "dvrButtonRenderer"):
        if isinstance(button, dict) and "dvrOn" in button:
            return bool(button["dvrOn"])
    return None


_TOAST_KINDS = (("Movie", "MOVIE"), ("Show", "SHOW"), ("Event", "EVENT"))


def _content_type(renderer):
    """MOVIE, SHOW or EVENT -- what YouTube TV says a tile is.

    A category tile says it outright in ``contentType``. Not every listing
    does: the one search answered with was drawn as a folder because this
    came back empty, and a film reached from search opened its page rather
    than playing.

    So the tile's own DVR toast is read when the field is absent. It is
    written per kind -- "Movie added to your library. We'll record it as it
    becomes available.", "Show added to your library. We'll record upcoming
    episodes...", "Event added to your library..." -- 1120, 873 and 14 of
    them across the captures, always agreeing with contentType where both
    are present.
    """
    named = renderer.get("contentType")
    if isinstance(named, str) and named:
        # **Trusted only as far as it goes.** A category tile is right: The
        # Accountant says MOVIE. A *search* tile from this client is not --
        # it typed The Blues Brothers and Blues Brothers 2000 SHOW, where a
        # browser types both MOVIE (2026-08-30 01:29). So a film found by
        # search is a folder, and what settles what it really is is the
        # header of its own page, which says MOVIE plainly.
        #
        # Matched on the word rather than the whole string, because the
        # vocabulary is not identical everywhere, and an unrecognised value
        # is handed back whole so a log names it rather than swallowing it.
        for _word, kind in _TOAST_KINDS:
            if kind in named.upper():
                return kind
        return named
    toast = text(first(renderer, "defaultToastText"))
    for word, kind in _TOAST_KINDS:
        if toast.startswith(word + " "):
            return kind
    return ""


def _lazy_token(content):
    """The continuation of a tab whose content holds nothing but that.

    Deliberately not fussy about the wrapper. page_continuation is fussy on
    purpose -- on a page full of shelves, reading the wrong continuation
    fetches more of one shelf, or the page again -- but a tab with no items
    has no shelves and nothing else to confuse: whatever continuation is in
    it is the one that fills it.

    A timedContinuationData is still skipped. That one is a refresh timer,
    and spending it asks for the same empty tab back on a schedule.
    """
    found = [""]

    def visit(node):
        if found[0] or not isinstance(node, (dict, list)):
            return
        if isinstance(node, list):
            for value in node:
                visit(value)
            return
        for name, value in node.items():
            if name == "timedContinuationData":
                continue            # a refresh timer: asks for this back
            if name == "continuation" and isinstance(value, str) and value:
                found[0] = value
                return
            visit(value)

    visit(content)
    return found[0]


def _tab_title(node, default=""):
    """A tab names itself with a plain string, where a shelf uses runs."""
    title = node.get("title")
    if isinstance(title, str):
        return title or default
    return text(title, default)


def page_chips(response):
    """The filter chips a category page carries, which name no row.

    A category -- Movies, say -- comes back as a nameless shelf of fifteen
    genre chips (Action, Comedy, Crime, Drama...) over its named rows.
    page_shelves drops that shelf, correctly: it has no title, and a folder
    called nothing is worse than no folder. But the chips are the page's own
    way of narrowing itself, and each is a real destination -- the same
    FEunplugged_chips with longer params -- so they are read separately and
    listed after the rows.
    """
    for entry in _section_list(response):
        if not isinstance(entry, dict):
            continue
        for shelf in entry.values():
            if not isinstance(shelf, dict) or _title_of(shelf):
                continue
            chips = shelf.get("content")
            if not isinstance(chips, dict):
                continue
            if not any(name.endswith("ChipListRenderer") for name in chips):
                continue
            found = parse_items(chips)
            if found:
                return found
    return []


def browse_tabs(response, least=2):
    """A page's tabs, when it is a page of tabs.

    A network page is one: ABC came back as eight -- LIVE, SERIES, DRAMA,
    COMEDY, NEWS, REALITY, DAYTIME, LATE NIGHT -- in a
    singleColumnBrowseResultsRenderer, and **only the selected one ships
    with anything in it.** The other seven carry an empty content holding a
    single nextContinuationData. That is why a network listed flat showed
    what was on now and nothing else: everything else on the page was a
    token nobody spent.

    The token is read from the tab's own section list rather than from
    anywhere below it, for the reason page_continuation is careful: the LIVE
    tab holds real shelves, and their continuations fetch more of one shelf,
    not the tab.

    ``least`` tabs must survive before this claims the page is tabbed, so a
    container holding one tab -- which is how FEunplugged_overlays answers,
    with an empty one -- reads as no tabs at all and the caller goes on
    listing the page the way it always did.
    """
    for block in walk(response, "tabs"):
        if not isinstance(block, list):
            continue
        tabs = []
        for entry in block:
            if not isinstance(entry, dict):
                continue
            renderer = entry.get("tabRenderer")
            if not isinstance(renderer, dict):
                continue
            title = _tab_title(renderer)
            if not title:
                continue
            content = renderer.get("content")
            if isinstance(content, dict):
                # Read from the tab's own section list, not from anywhere
                # below it: the selected tab holds real shelves, and their
                # continuations fetch more of one shelf.
                token = page_continuation(content) or ""
                items = parse_items(content)
                if not items and not token:
                    # A content this could not read at all. A tab holding
                    # no items holds no shelves either, so any continuation
                    # in it is the tab's own, whatever shape it came in.
                    #
                    # Which shape took three readings to pin down, because
                    # the wrapper is the only thing that differs and it was
                    # the one thing not being printed: the tab that reads
                    # and the tab that does not both hold exactly one
                    # string, both under a key called "continuation", both
                    # inside one sectionListRenderer. The web client wraps
                    # it in nextContinuationData; this one does not.
                    token = (continuation_token(content)
                             or _lazy_token(content))
                browse_id = params = ""
            else:
                # A tab carrying no content at all cannot be hiding a
                # shelf's token, so here the whole tab is fair to search --
                # and it may name a page rather than a continuation. The web
                # client defers with a token; a tab that defers with a
                # browse id is read the same way from the caller's side.
                items = []
                found = first(renderer, "continuation")
                token = found if isinstance(found, str) else ""
                # Searched over the whole tab, and only here. Elsewhere an
                # endpoint is looked for under the handful of keys a tile
                # keeps its destination under, because a tile's menu holds
                # endpoints for other things entirely. A tab with no content
                # has no menu and no shelves: whatever browseEndpoint is in
                # it is the tab's own, whatever key it arrived under.
                endpoint = first(renderer, "browseEndpoint")
                if not isinstance(endpoint, dict):
                    endpoint = {}
                browse_id = endpoint.get("browseId") or ""
                params = endpoint.get("params") or ""
                if not isinstance(browse_id, str):
                    browse_id = ""
                if not isinstance(params, str):
                    params = ""
            # A tab with none of the three is a heading for nothing.
            if items or token or browse_id:
                tabs.append(Section(title, items, token, browse_id, params))
        if len(tabs) >= least:
            return tabs
    return []


def tab_shapes(response, limit=12):
    """What every tab on a page carries, named, for the log.

    browse_tabs drops a tab it can find nothing in, and a count cannot say
    whether a page had two tabs or had six and four were unreadable. Adult
    Swim answered the web client with four and the TV client with two, and
    only the keys the dropped ones carry say which of those two things
    happened.
    """
    out = []
    for block in walk(response, "tabs"):
        if not isinstance(block, list):
            continue
        for entry in block:
            if not isinstance(entry, dict) or len(out) >= limit:
                continue
            renderer = entry.get("tabRenderer")
            if not isinstance(renderer, dict):
                continue
            line = "%s carries [%s]" % (_tab_title(renderer) or "(unnamed)",
                                        ", ".join(sorted(renderer)))
            # For a tab this could read nothing out of, the tab's own keys
            # are not the answer -- every tab on a network page carries
            # [content, title, trackingParams], the two that read and the
            # two that do not alike. What is *inside* the content is the
            # only thing that separates them.
            content = renderer.get("content")
            if isinstance(content, dict) and not parse_items(content):
                line += "; content " + _inside(content)
            out.append(line)
        if out:
            return out
    return out


def _inside(node, limit=6):
    """A one-line account of what a small subtree holds."""
    counts = {}
    plain = []

    def visit(node, path):
        if isinstance(node, dict):
            for key, value in node.items():
                if key.endswith("Renderer") and isinstance(value, dict):
                    counts[key] = counts.get(key, 0) + 1
                elif (isinstance(value, str) and value
                        and key not in ("trackingParams", "clickTrackingParams")):
                    # The whole path, not the last key. A tab that reads and
                    # a tab that does not both ended "...continuation", and
                    # the wrapper between is the entire difference.
                    where = "/".join(path + [key])
                    if where not in plain:
                        plain.append(where)
                visit(value, path + [key])
        elif isinstance(node, list):
            for value in node:
                visit(value, path)

    visit(node, [])
    ranked = sorted(counts.items(), key=lambda pair: -pair[1])[:limit]
    return ("[%s] holding %s%s"
            % (", ".join(sorted(node)) if isinstance(node, dict) else "?",
               ", ".join("%s x%d" % pair for pair in ranked) or "no renderers",
               "; strings under " + ", ".join(plain[:limit]) if plain else ""))


def describe(response, limit=40):
    """A compact account of a response's shape, for the log.

    Printed when a page arrives in a container this addon does not know.
    Naming the renderers that came back, and the lists they sit in, is the
    difference between "the Library did not parse" and knowing what to
    write next.
    """
    counts = {}
    lists = []

    def visit(node, path):
        if isinstance(node, dict):
            for key, value in node.items():
                if key.endswith("Renderer") and isinstance(value, dict):
                    counts[key] = counts.get(key, 0) + 1
                visit(value, path + "/" + key)
        elif isinstance(node, list):
            names = [name for entry in node if isinstance(entry, dict)
                     for name in entry if name.endswith("Renderer")]
            if len(names) >= 2:
                seen = []
                for name in names:
                    if name not in seen:
                        seen.append(name)
                lists.append((path, len(node), ",".join(seen[:4])))
            for index, value in enumerate(node):
                visit(value, path + "[%d]" % index)

    visit(response, "")
    ranked = sorted(counts.items(), key=lambda pair: -pair[1])[:limit]
    lists.sort(key=lambda row: -row[1])
    return ("top-level keys: %s\n  renderers: %s\n  lists: %s"
            % (", ".join(sorted(response.keys())) if isinstance(response, dict)
               else type(response).__name__,
               ", ".join("%s x%d" % pair for pair in ranked) or "none",
               " | ".join("%s (%d: %s)" % row for row in lists[:8]) or "none"))
